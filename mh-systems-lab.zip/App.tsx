import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Programmes from './pages/Programmes';
import ProgramDetail from './pages/ProgramDetail';
import Courses from './pages/Courses';
import CourseDetail from './pages/CourseDetail';
import Contact from './pages/Contact';
import AiTools from './pages/AiTools';
import Podcast from './pages/Podcast';
import PodcastEpisode from './pages/PodcastEpisode';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import Disclaimer from './pages/Disclaimer';
import RefundPolicy from './pages/RefundPolicy';
import CookiePolicy from './pages/CookiePolicy';

// Placeholder components for routes not fully detailed in this specific prompt response
const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
  <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
    <h1 className="text-4xl font-bold text-sovereign-gold mb-4">{title}</h1>
    <p className="text-gray-400 mb-8">This section is currently being updated with new resources.</p>
    <a href="/#/contact" className="px-6 py-3 border border-sovereign-gold text-sovereign-gold rounded-lg hover:bg-sovereign-gold hover:text-black transition-colors">Contact for Details</a>
  </div>
);

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/programmes" element={<Programmes />} />
          <Route path="/programmes/:programId" element={<ProgramDetail />} />
          <Route path="/courses" element={<Courses />} />
          <Route path="/courses/:courseId" element={<CourseDetail />} />
          <Route path="/ai-tools" element={<AiTools />} />
          
          <Route path="/podcast" element={<Podcast />} />
          <Route path="/podcast/:slug" element={<PodcastEpisode />} />
          
          <Route path="/resources" element={<Blog />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />

          <Route path="/contact" element={<Contact />} />
          
          {/* Legal Pages */}
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/terms-of-service" element={<TermsOfService />} />
          <Route path="/disclaimer" element={<Disclaimer />} />
          <Route path="/refund-policy" element={<RefundPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />

          {/* Placeholder Routes */}
          <Route path="/experts" element={<PlaceholderPage title="Expert Network" />} />
          <Route path="/about" element={<PlaceholderPage title="About MH Systems Lab" />} />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;