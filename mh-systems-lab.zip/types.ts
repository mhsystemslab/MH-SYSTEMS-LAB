import React from 'react';

export interface NavItem {
  label: string;
  path: string;
  isButton?: boolean;
}

export interface Program {
  id: string;
  title: string;
  tagline: string;
  description: string;
  icon: React.ReactNode;
  features: string[];
  link: string;
}

export interface Course {
  id: string;
  title: string;
  duration: string;
  description: string;
  features: string[];
  gumroadLink: string;
}

export interface Stat {
  value: string;
  label: string;
}

export interface TeamMember {
  name: string;
  role: string;
  specialty: string;
  description: string;
}