import React from 'react';
import { useParams, NavLink, Navigate } from 'react-router-dom';
import { Calendar, Clock, User, ArrowLeft, Share2, Facebook, Twitter, Linkedin } from 'lucide-react';

const BlogPost: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();

  // Mock Content
  const post = {
    title: "The Neuroscience of Breaking Limiting Beliefs",
    category: "Mental Mastery",
    author: "MH Systems Team",
    date: "Dec 15, 2024",
    readTime: "8 min read",
    content: (
      <>
        <p className="mb-6 text-lg leading-relaxed text-gray-300">
          Your brain is a prediction machine, constantly using past experiences to anticipate future outcomes. 
          When these predictions become rigid, they form what we call "limiting beliefs"—neural pathways that filter reality to confirm your fears rather than your potential.
        </p>
        
        <h2 className="text-2xl font-bold text-white mt-12 mb-6">Understanding the Neuroscience</h2>
        <p className="mb-6 text-gray-400 leading-relaxed">
          Recent advances in neuroimaging have revealed that beliefs are not abstract concepts but physical structures in the brain. 
          They are strengthened through a process called Long-Term Potentiation (LTP)—essentially, "neurons that fire together, wire together."
        </p>
        <p className="mb-6 text-gray-400 leading-relaxed">
          To break a limiting belief, we must interrupt this firing pattern and introduce a new cognitive pathway. 
          This process, known as self-directed neuroplasticity, requires conscious effort, repetition, and emotional intensity.
        </p>

        <h2 className="text-2xl font-bold text-white mt-12 mb-6">Evidence-Based Breaking Techniques</h2>
        <ul className="list-disc pl-6 space-y-4 text-gray-400 mb-8">
          <li><strong>Cognitive Reframing:</strong> Identify the belief, challenge its validity with evidence, and construct a more accurate alternative.</li>
          <li><strong>Somatic Interruption:</strong> Use physical movement to disrupt the emotional state associated with the limiting belief.</li>
          <li><strong>Visualization:</strong> Mental rehearsal activates the same neural networks as physical action, priming the brain for new behaviors.</li>
        </ul>

        <div className="bg-sovereign-gold/10 border-l-4 border-sovereign-gold p-6 my-8 rounded-r-lg">
          <p className="text-sovereign-gold italic font-medium">
            "You are not your thoughts; you are the observer of your thoughts. In that space of observation lies your power to choose."
          </p>
        </div>

        <h2 className="text-2xl font-bold text-white mt-12 mb-6">Implementation Strategy</h2>
        <p className="mb-6 text-gray-400 leading-relaxed">
          We recommend a 21-day protocol of daily journaling and mindfulness practice. 
          Start by writing down one limiting belief each morning and three pieces of evidence that contradict it. 
          Over time, this weakens the old neural pathway and strengthens the new, sovereign mindset.
        </p>
      </>
    )
  };

  if (!slug) return <Navigate to="/blog" />;

  const currentUrl = encodeURIComponent(window.location.href);
  const shareTitle = encodeURIComponent(post.title);

  const shareLinks = {
    twitter: `https://twitter.com/intent/tweet?text=${shareTitle}&url=${currentUrl}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${currentUrl}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${currentUrl}`
  };

  return (
    <article className="max-w-4xl mx-auto px-4 py-12 pb-24">
      {/* Back Link */}
      <NavLink to="/blog" className="inline-flex items-center gap-2 text-gray-400 hover:text-sovereign-gold transition-colors mb-8 text-sm font-medium">
        <ArrowLeft size={16} /> Back to Lab Notes
      </NavLink>

      {/* Header */}
      <header className="mb-12 text-center">
        <div className="inline-block px-3 py-1 mb-6 bg-sovereign-gold/10 text-sovereign-gold text-xs font-bold rounded uppercase tracking-wider border border-sovereign-gold/20">
          {post.category}
        </div>
        <h1 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
          {post.title}
        </h1>
        
        <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <User size={14} />
            </div>
            <span>{post.author}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar size={14} /> <span>{post.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock size={14} /> <span>{post.readTime}</span>
          </div>
        </div>
      </header>

      {/* Featured Image Placeholder */}
      <div className="w-full h-64 md:h-96 bg-gradient-to-br from-sovereign-gold/10 to-[#0F2027] rounded-2xl mb-12 border border-white/10 flex items-center justify-center">
        <span className="text-sovereign-gold/30 font-bold text-4xl">Featured Image</span>
      </div>

      {/* Content */}
      <div className="prose prose-invert prose-lg max-w-none mb-12">
        {post.content}
      </div>

      {/* Footer / Share */}
      <footer className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <span className="text-sm font-medium text-gray-400 flex items-center gap-2">
            <Share2 size={16} /> Share this article:
          </span>
          <div className="flex gap-2">
            <a 
              href={shareLinks.twitter}
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-white/5 rounded-full hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex items-center justify-center"
              aria-label="Share on Twitter"
            >
              <Twitter size={18} />
            </a>
            <a 
              href={shareLinks.linkedin}
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-white/5 rounded-full hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex items-center justify-center"
              aria-label="Share on LinkedIn"
            >
              <Linkedin size={18} />
            </a>
            <a 
              href={shareLinks.facebook}
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 bg-white/5 rounded-full hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex items-center justify-center"
              aria-label="Share on Facebook"
            >
              <Facebook size={18} />
            </a>
          </div>
        </div>

        <NavLink 
          to="/contact" 
          className="px-6 py-3 bg-sovereign-gold text-[#0F2027] font-bold rounded-lg text-sm hover:bg-white transition-colors"
        >
          Book a Consultation
        </NavLink>
      </footer>
    </article>
  );
};

export default BlogPost;