import React from 'react';
import { NavLink } from 'react-router-dom';
import { Leaf, Rocket, Brain, CheckCircle, ArrowRight } from 'lucide-react';

const Programmes: React.FC = () => {
  const programmes = [
    {
      id: 'sovereign-reset',
      title: 'Sovereign Reset™',
      subtitle: 'Health & Metabolic Optimization',
      icon: Leaf,
      description: 'Reverse chronic conditions, optimize metabolic health, and build sustainable wellness systems.',
      features: [
        'Personalized nutrition protocols',
        'Metabolic health restoration',
        'Fitness system design',
        'Chronic condition management'
      ]
    },
    {
      id: 'sovereign-builder',
      title: 'Sovereign Builder™',
      subtitle: 'Business Launch & Growth',
      icon: Rocket,
      featured: true,
      description: 'From zero to profitable business in 30 days. Complete business development and AI automation.',
      features: [
        'Business ideation to launch',
        'Brand identity & positioning',
        'Website & digital presence',
        'Marketing automation systems'
      ]
    },
    {
      id: 'sovereign-mind',
      title: 'Sovereign Mind™',
      subtitle: 'Mental Mastery',
      icon: Brain,
      description: 'Build unshakeable mental resilience, emotional mastery, and cognitive performance.',
      features: [
        'Emotional regulation frameworks',
        'Cognitive restructuring',
        'Stress management systems',
        'Faith-integrated healing'
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
          Transform Every Dimension
        </h1>
        <p className="text-xl text-sovereign-gold italic">The Sovereign Method™ Programmes</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {programmes.map((prog) => (
          <div 
            key={prog.id} 
            className={`relative p-8 rounded-2xl backdrop-blur-md border transition-all duration-300 hover:scale-105 flex flex-col ${
              prog.featured 
                ? 'bg-sovereign-gold/10 border-sovereign-gold shadow-[0_0_30px_rgba(212,175,55,0.15)]' 
                : 'bg-white/5 border-white/10 hover:border-sovereign-gold/50'
            }`}
          >
            {prog.featured && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-sovereign-gold text-[#0F2027] px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                Most Popular
              </div>
            )}
            
            <div className="bg-white/5 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 border border-white/10 text-sovereign-gold">
              <prog.icon size={32} />
            </div>

            <h3 className="text-2xl font-bold mb-1">{prog.title}</h3>
            <p className="text-sovereign-light text-sm mb-4 font-medium">{prog.subtitle}</p>
            <p className="text-gray-400 mb-8 leading-relaxed flex-grow">{prog.description}</p>

            <ul className="space-y-3 mb-8">
              {prog.features.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-3 text-sm text-gray-300">
                  <CheckCircle size={16} className="text-sovereign-gold shrink-0 mt-0.5" />
                  {feature}
                </li>
              ))}
            </ul>

            <div className="mt-auto space-y-3">
               <NavLink 
                to={`/programmes/${prog.id}`}
                className={`flex items-center justify-center gap-2 w-full py-3 rounded-lg font-bold text-center transition-colors ${
                  prog.featured 
                    ? 'bg-sovereign-gold text-[#0F2027] hover:bg-white' 
                    : 'border border-sovereign-gold text-sovereign-gold hover:bg-sovereign-gold hover:text-[#0F2027]'
                }`}
              >
                View Full Curriculum <ArrowRight size={18} />
              </NavLink>
              <p className="text-center text-xs text-gray-500">Flexible pricing available</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 p-6 rounded-xl bg-white/5 border border-white/10 text-center">
        <p className="text-gray-300">
          <span className="text-sovereign-gold font-bold">💰 We work with ALL budgets.</span> Contact us for custom payment plans, scholarships, or reduced rates.
        </p>
      </div>
    </div>
  );
};

export default Programmes;