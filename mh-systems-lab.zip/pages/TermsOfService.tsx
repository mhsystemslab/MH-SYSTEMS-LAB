import React from 'react';

const TermsOfService: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-24">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white">Terms of Service</h1>
        <p className="text-sm text-gray-400 mb-8 uppercase tracking-widest border-b border-white/10 pb-4">Last Updated: December 2024</p>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">1. Acceptance of Terms</h2>
            <p>By accessing and using MH Systems Lab services, you agree to be bound by these Terms of Service.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">2. Services Provided</h2>
            <p className="mb-4">MH Systems Lab offers:</p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Transformation programs (Sovereign Reset™, Sovereign Builder™, Sovereign Mind™)</li>
              <li>Online certification courses</li>
              <li>AI tools and systems</li>
              <li>Expert consultations and coaching</li>
              <li>Digital resources and educational content</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">3. User Responsibilities</h2>
            <p className="mb-4">You agree to:</p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Provide accurate and complete information</li>
              <li>Maintain confidentiality of your account</li>
              <li>Use services only for lawful purposes</li>
              <li>Not share proprietary content</li>
              <li>Engage respectfully with staff and community</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">4. Payment Terms</h2>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>All prices provided upon request</li>
              <li>Flexible payment plans available</li>
              <li>Payment required before accessing premium content</li>
              <li>We accept various payment methods</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">5. Intellectual Property</h2>
            <p className="mb-4">All content is owned by MH Systems Lab and protected by copyright. You may not:</p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Reproduce content without permission</li>
              <li>Use trademarks without authorization</li>
              <li>Reverse engineer our systems</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">6. Limitation of Liability</h2>
            <p>MH Systems Lab provides educational services. We do not provide medical, legal, or financial advice. Results vary by individual.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">7. Disclaimer</h2>
            <p>Our services are provided "as is" without warranties of any kind.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">8. Modifications</h2>
            <p>We may modify these terms at any time. Continued use constitutes acceptance.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">9. Contact</h2>
            <p>For questions: <a href="mailto:legal@mhsystemslab.com" className="text-sovereign-gold hover:underline">legal@mhsystemslab.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;