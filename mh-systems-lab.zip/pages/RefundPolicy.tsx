import React from 'react';

const RefundPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-24">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white">Refund Policy</h1>
        <p className="text-sm text-gray-400 mb-8 uppercase tracking-widest border-b border-white/10 pb-4">Last Updated: December 2024</p>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Our Commitment</h2>
            <p>We stand behind our programs and want you to be completely satisfied.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">30-Day Satisfaction Guarantee</h2>
            <p className="mb-4">Most programs include a 30-day satisfaction guarantee:</p>
            
            <h3 className="text-xl font-semibold text-sovereign-gold mb-2">Eligibility</h3>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Request within 30 days of purchase</li>
              <li>Demonstrate engagement with the program</li>
              <li>Provide specific feedback on improvements needed</li>
            </ul>
            
            <h3 className="text-xl font-semibold text-sovereign-gold mb-2">What's Covered</h3>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Digital courses and programs</li>
              <li>Certification training</li>
              <li>Coaching packages (first 30 days)</li>
            </ul>
            
            <h3 className="text-xl font-semibold text-sovereign-gold mb-2">What's Not Covered</h3>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Completed consultation sessions</li>
              <li>Custom services once work has begun</li>
              <li>Services at discounted rates</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Flexible Pricing</h2>
            <p className="mb-4">If you're experiencing financial hardship, we offer:</p>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Extended payment plans</li>
              <li>Reduced rates based on circumstances</li>
              <li>Scholarship opportunities</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Contact for Refunds</h2>
            <p>Email: <a href="mailto:refunds@mhsystemslab.com" className="text-sovereign-gold hover:underline">refunds@mhsystemslab.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default RefundPolicy;