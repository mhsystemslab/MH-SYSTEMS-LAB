import React from 'react';

const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-24">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white">Privacy Policy</h1>
        <p className="text-sm text-gray-400 mb-8 uppercase tracking-widest border-b border-white/10 pb-4">Last Updated: December 2024</p>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">1. Information We Collect</h2>
            <p className="mb-4">MH Systems Lab collects the following information when you interact with our website and services:</p>
            
            <h3 className="text-xl font-semibold text-sovereign-gold mb-2">Personal Information</h3>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Name, email address, phone number</li>
              <li>Payment information (processed securely through third-party providers)</li>
              <li>Program enrollment and progress data</li>
              <li>Consultation notes and transformation goals</li>
            </ul>
            
            <h3 className="text-xl font-semibold text-sovereign-gold mb-2">Automatically Collected Information</h3>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>IP address, browser type, device information</li>
              <li>Pages visited, time spent on site</li>
              <li>Referring website or source</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">2. How We Use Your Information</h2>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>To provide and deliver our programs, courses, and services</li>
              <li>To communicate with you about your transformation journey</li>
              <li>To process payments and send receipts</li>
              <li>To send educational content, updates, and promotional materials (with your consent)</li>
              <li>To improve our website, services, and customer experience</li>
              <li>To comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">3. How We Protect Your Information</h2>
            <p className="mb-4">We implement industry-standard security measures including:</p>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>SSL encryption for all data transmission</li>
              <li>Secure cloud storage with Cloudflare R2</li>
              <li>Regular security audits and updates</li>
              <li>Limited access to personal data by authorized personnel only</li>
              <li>PCI-compliant payment processing</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">4. Information Sharing</h2>
            <p className="mb-4">We do not sell, trade, or rent your personal information. We may share information with:</p>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li><strong>Service Providers:</strong> Payment processors, email providers, hosting services</li>
              <li><strong>Expert Network:</strong> Relevant specialists when you book consultations (with your consent)</li>
              <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">5. Your Rights</h2>
            <p className="mb-4">You have the right to:</p>
            <ul className="list-disc pl-5 mb-4 space-y-2 marker:text-sovereign-gold">
              <li>Access, update, or delete your personal information</li>
              <li>Opt-out of marketing communications</li>
              <li>Request a copy of your data</li>
              <li>Withdraw consent at any time</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">6. Cookies</h2>
            <p className="mb-4">We use cookies to enhance your experience. You can control cookie settings through your browser.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">7. Third-Party Links</h2>
            <p className="mb-4">Our website may contain links to third-party sites. We are not responsible for their privacy practices.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">8. Children's Privacy</h2>
            <p className="mb-4">Our services are not directed to individuals under 18. We do not knowingly collect information from minors.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">9. International Data Transfers</h2>
            <p className="mb-4">Your information may be transferred to and processed in countries where our servers operate.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">10. Changes to This Policy</h2>
            <p className="mb-4">We may update this policy periodically. Changes will be posted on this page.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">11. Contact Us</h2>
            <p className="mb-4">For privacy questions, contact us at: <a href="mailto:privacy@mhsystemslab.com" className="text-sovereign-gold hover:underline">privacy@mhsystemslab.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;