import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Bot, 
  BarChart2, 
  Activity, 
  PenTool, 
  Sun, 
  Wallet, 
  Zap, 
  Clock, 
  Users, 
  Target, 
  ArrowRight,
  Cpu
} from 'lucide-react';

const AiTools: React.FC = () => {
  const tools = [
    {
      icon: Bot,
      name: "AI Life Architect",
      category: "Personal Development",
      description: "Personal development automation. Design your life structure, habits, and long-term vision with algorithmic precision."
    },
    {
      icon: BarChart2,
      name: "Business Intelligence Suite",
      category: "Business Growth",
      description: "Revenue & growth analytics. Real-time dashboards and predictive modeling for your business decisions."
    },
    {
      icon: Activity,
      name: "Health Optimization AI",
      category: "Health",
      description: "Metabolic tracking & insights. Analyze nutritional data and biometric feedback to optimize physical performance."
    },
    {
      icon: PenTool,
      name: "Content Creation System",
      category: "Marketing",
      description: "Marketing automation. Generate months of social media content, blogs, and emails in minutes."
    },
    {
      icon: Sun,
      name: "Wellness Companion",
      category: "Wellbeing",
      description: "Daily habit tracking. Smart reminders and adjustments based on your energy levels and progress."
    },
    {
      icon: Wallet,
      name: "Financial Intelligence",
      category: "Finance",
      description: "Budgeting & wealth building. Automated cash flow management and investment forecasting strategies."
    },
    {
      icon: Zap,
      name: "Learning Accelerator",
      category: "Education",
      description: "Educational optimization. Personalized curriculum generation and retention systems for rapid skill acquisition."
    },
    {
      icon: Clock,
      name: "Productivity Maximizer",
      category: "Productivity",
      description: "Time & energy management. AI-driven schedule optimization to align tasks with your peak cognitive hours."
    },
    {
      icon: Users,
      name: "Relationship Navigator",
      category: "Relationships",
      description: "Communication frameworks. Analysis tools for conflict resolution and deepening interpersonal connections."
    },
    {
      icon: Target,
      name: "Strategic Planner",
      category: "Goal Setting",
      description: "Goal achievement systems. Breakdown big ambitious goals into actionable daily steps with progress tracking."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 pb-24">
      {/* Header */}
      <div className="text-center mb-16 space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-sovereign-gold/30 bg-sovereign-gold/10 text-sovereign-gold text-sm font-medium">
          <Cpu size={14} />
          <span>Automated Intelligence</span>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold text-white">
          10 AI Systems for <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-sovereign-gold to-white">Total Transformation</span>
        </h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light">
          Automated intelligence amplifying your results across all life domains. Included with our programmes or available as a standalone suite.
        </p>
      </div>

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-20">
        {tools.map((tool, idx) => (
          <div 
            key={idx} 
            className="group relative p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:border-sovereign-gold/50 transition-all duration-300 hover:-translate-y-1 flex flex-col h-full"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-sovereign-gold/5 to-transparent opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-300 pointer-events-none"></div>
            
            <div className="mb-5 p-3 rounded-xl bg-white/5 w-fit border border-white/10 text-sovereign-gold group-hover:scale-110 transition-transform duration-300">
              <tool.icon size={28} />
            </div>
            
            <h3 className="text-lg font-bold mb-2 text-white group-hover:text-sovereign-gold transition-colors">
              {tool.name}
            </h3>
            
            <p className="text-sm text-gray-400 leading-relaxed mb-6 flex-grow">
              {tool.description}
            </p>
            
            <div className="mt-auto pt-4 border-t border-white/5 flex justify-between items-center">
              <span className="text-[10px] uppercase tracking-widest text-sovereign-light/70 font-semibold">
                {tool.category}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* CTA Section */}
      <div className="max-w-4xl mx-auto">
        <div className="relative p-8 md:p-12 rounded-3xl bg-white/5 border border-sovereign-gold/30 backdrop-blur-xl overflow-hidden text-center">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-sovereign-gold to-transparent"></div>
          
          <h2 className="text-3xl font-bold mb-4">Access Options</h2>
          <p className="text-gray-300 mb-8 max-w-lg mx-auto">
            These AI systems are included with all our major transformation programmes. 
            They are also available as a standalone digital toolkit.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <NavLink 
              to="/contact" 
              className="w-full sm:w-auto px-8 py-4 bg-sovereign-gold text-[#0F2027] rounded-lg font-bold text-lg hover:bg-white transition-all duration-300 shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2"
            >
              Request AI Tools Catalogue <ArrowRight size={20} />
            </NavLink>
            <NavLink 
              to="/contact" 
              className="w-full sm:w-auto px-8 py-4 border border-sovereign-gold text-sovereign-gold rounded-lg font-bold text-lg hover:bg-sovereign-gold/10 transition-all duration-300"
            >
              Contact Support
            </NavLink>
          </div>
          
          <p className="mt-6 text-xs text-gray-500">
            * Custom enterprise access packages available for organizations.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AiTools;