import React, { useState } from 'react';
import { useParams, NavLink, Navigate } from 'react-router-dom';
import { Play, Pause, Calendar, Clock, ArrowLeft, Share2, Mic, Headphones, Twitter, Linkedin, Facebook } from 'lucide-react';

const PodcastEpisode: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [isPlaying, setIsPlaying] = useState(false);

  // Mock Data (In a real app, fetch from API/CMS)
  const episodes: Record<string, any> = {
    "breaking-free-limiting-beliefs": {
      id: 47,
      title: "Breaking Free from Limiting Beliefs",
      date: "Dec 15, 2024",
      duration: "45 min",
      description: "Discover how to identify and eliminate the beliefs that keep you stuck in struggle mode. We dive deep into cognitive restructuring techniques and the neuroscience of change.",
      showNotes: `
        <p class="mb-4">Your brain is a prediction machine, constantly using past experiences to anticipate future outcomes. When these predictions become rigid, they form what we call "limiting beliefs"—neural pathways that filter reality to confirm your fears rather than your potential.</p>
        
        <h3 class="text-xl font-bold text-white mt-8 mb-4">In this episode, we cover:</h3>
        <ul class="list-disc pl-5 space-y-2 mb-6 text-gray-300">
          <li><strong>The Neuroscience of Belief:</strong> How thoughts become physical structures in the brain.</li>
          <li><strong>The RAS Filter:</strong> Why you only see what you believe is possible.</li>
          <li><strong>3-Step Reframing Protocol:</strong> A practical exercise to dismantle negative thought patterns.</li>
          <li><strong>Identity Shifting:</strong> How to embody the version of you who has already succeeded.</li>
        </ul>

        <h3 class="text-xl font-bold text-white mt-8 mb-4">Resources Mentioned:</h3>
        <ul class="list-disc pl-5 space-y-2 mb-6 text-gray-300">
          <li><a href="/programmes/sovereign-mind" class="text-sovereign-gold hover:underline">Sovereign Mind™ Program</a></li>
          <li><a href="/resources" class="text-sovereign-gold hover:underline">Free Cognitive Reframing Worksheet</a></li>
        </ul>
      `,
      image: "bg-blue-500/10"
    },
    "science-metabolic-optimization": {
      id: 46,
      title: "The Science of Metabolic Optimization",
      date: "Dec 08, 2024",
      duration: "38 min",
      description: "Learn evidence-based strategies for optimizing your metabolism, including circadian alignment and nutrient timing.",
      showNotes: "<p>Detailed show notes about metabolic health...</p>",
      image: "bg-green-500/10"
    },
    "idea-to-profitable-business": {
      id: 45,
      title: "From Idea to Profitable Business",
      date: "Dec 01, 2024",
      duration: "52 min",
      description: "Complete framework for launching your first profitable business. From validation to your first sale in 30 days.",
      showNotes: "<p>Detailed show notes about business launching...</p>",
      image: "bg-sovereign-gold/10"
    }
  };

  const episode = slug ? episodes[slug] : undefined;

  if (!episode) {
    return <Navigate to="/podcast" replace />;
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12 pb-24">
      {/* Back Link */}
      <NavLink to="/podcast" className="inline-flex items-center gap-2 text-gray-400 hover:text-sovereign-gold transition-colors mb-8 text-sm font-medium">
        <ArrowLeft size={16} /> Back to All Episodes
      </NavLink>

      {/* Main Player Section */}
      <div className="bg-white/5 backdrop-blur-xl border border-sovereign-gold/30 rounded-3xl p-8 md:p-12 relative overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.3)] mb-12">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Headphones size={200} className="text-white" />
        </div>
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row gap-8 items-center">
             {/* Play Button & Viz */}
            <div className="shrink-0">
               <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-black/40 border-4 border-sovereign-gold/20 flex items-center justify-center relative group cursor-pointer" onClick={() => setIsPlaying(!isPlaying)}>
                {isPlaying ? <Pause size={40} className="text-sovereign-gold" /> : <Play size={40} className="text-sovereign-gold ml-2" />}
                
                {/* Waveform Animation */}
                <div className={`absolute inset-0 flex items-center justify-center gap-1 ${isPlaying ? 'opacity-100' : 'opacity-30'}`}>
                  {[...Array(6)].map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-1 bg-sovereign-gold/60 rounded-full transition-all duration-300`}
                      style={{
                        height: isPlaying ? `${Math.random() * 60 + 20}%` : '20%',
                        animation: isPlaying ? `pulse 0.5s infinite alternate ${i * 0.1}s` : 'none'
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Meta Data */}
            <div className="w-full space-y-4">
               <div className="flex items-center gap-3 text-sm text-sovereign-gold">
                <span className="px-2 py-1 bg-sovereign-gold/10 rounded border border-sovereign-gold/20 font-mono">Episode #{episode.id}</span>
                <span className="flex items-center gap-1"><Calendar size={14} /> {episode.date}</span>
                <span className="flex items-center gap-1 ml-2"><Clock size={14} /> {episode.duration}</span>
              </div>
              
              <h1 className="text-3xl md:text-4xl font-bold text-white leading-tight">
                {episode.title}
              </h1>
              
              {/* Progress Bar (Mock) */}
              <div className="flex items-center gap-4 pt-2">
                 <button 
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="shrink-0 px-6 py-2 bg-sovereign-gold text-[#0F2027] font-bold rounded-lg hover:bg-white transition-colors flex items-center gap-2 text-sm"
                >
                  {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                  {isPlaying ? 'Pause' : 'Play'}
                </button>
                <div className="grow h-1.5 bg-white/10 rounded-full overflow-hidden">
                   <div className="h-full bg-sovereign-gold w-[30%] rounded-full"></div>
                </div>
                <span className="text-xs text-gray-400 font-mono">14:20</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Show Notes */}
        <div className="lg:col-span-2">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 backdrop-blur-md">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <Mic className="text-sovereign-gold" size={24} /> Show Notes
            </h2>
            <div 
              className="prose prose-invert prose-lg max-w-none text-gray-300 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: episode.showNotes }}
            />
          </div>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-1 space-y-8">
           {/* Subscribe */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-4">Subscribe</h3>
            <div className="space-y-3">
              <button className="w-full py-3 bg-[#0F2027] border border-white/10 hover:border-sovereign-gold text-white rounded-lg flex items-center justify-center gap-2 transition-colors">
                Listen on Apple Podcasts
              </button>
              <button className="w-full py-3 bg-[#0F2027] border border-white/10 hover:border-sovereign-gold text-white rounded-lg flex items-center justify-center gap-2 transition-colors">
                Listen on Spotify
              </button>
              <button className="w-full py-3 bg-[#0F2027] border border-white/10 hover:border-sovereign-gold text-white rounded-lg flex items-center justify-center gap-2 transition-colors">
                Listen on Google
              </button>
            </div>
          </div>

          {/* Share */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
              <Share2 size={18} /> Share Episode
            </h3>
            <div className="flex gap-2">
              <button className="flex-1 p-3 bg-white/5 rounded-lg hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex justify-center"><Twitter size={20} /></button>
              <button className="flex-1 p-3 bg-white/5 rounded-lg hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex justify-center"><Linkedin size={20} /></button>
              <button className="flex-1 p-3 bg-white/5 rounded-lg hover:bg-sovereign-gold hover:text-[#0F2027] transition-colors flex justify-center"><Facebook size={20} /></button>
            </div>
          </div>

          {/* About Host */}
          <div className="bg-gradient-to-br from-sovereign-gold/10 to-transparent border border-sovereign-gold/20 rounded-2xl p-6">
            <h4 className="font-bold text-sovereign-gold mb-2">Hosted by Mohamoud Hassan</h4>
            <p className="text-sm text-gray-400">
              Human Transformation Strategist exploring the systems behind elite performance in mind, body, and business.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default PodcastEpisode;