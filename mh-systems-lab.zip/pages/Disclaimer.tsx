import React from 'react';

const Disclaimer: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-24">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white">Professional Disclaimer</h1>
        <p className="text-sm text-gray-400 mb-8 uppercase tracking-widest border-b border-white/10 pb-4">Last Updated: December 2024</p>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Professional Expertise</h2>
            <p className="mb-4"><strong>MH Systems Lab is led by a qualified professional with expertise in:</strong></p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Qualified Counsellor</li>
              <li>Holistic Life Coach</li>
              <li>Certified Nutritionist</li>
              <li>Health Coach</li>
              <li>Business Developer</li>
              <li>Conflict Resolution Expert</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Scope of Practice</h2>
            <p className="mb-4"><strong>Our services include:</strong></p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Life coaching and personal development</li>
              <li>Holistic wellness and nutrition education</li>
              <li>Business development and entrepreneurship training</li>
              <li>Relationship and communication coaching</li>
              <li>Conflict resolution strategies</li>
              <li>Educational programs and workshops</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Not Medical Services</h2>
            <p className="mb-4"><strong>Important: We do not provide medical services:</strong></p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Not a medical doctor or physician</li>
              <li>Does not provide medical diagnosis or treatment</li>
              <li>Not a licensed mental health provider</li>
              <li>Does not prescribe medication</li>
              <li>Does not provide medical advice</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Educational Purpose</h2>
            <p>All services are educational and coaching in nature, designed to support personal transformation and development.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Professional Boundaries</h2>
            <p>Our coaching and educational services complement but do not replace professional medical, legal, or financial advice.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Individual Results</h2>
            <p><strong>Individual results vary.</strong> Success depends on personal commitment, circumstances, and consistent application of strategies.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Professional Referrals</h2>
            <p className="mb-4">We encourage clients to consult appropriate professionals for:</p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Medical concerns and health issues</li>
              <li>Mental health conditions requiring treatment</li>
              <li>Legal matters and disputes</li>
              <li>Financial planning and investment decisions</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Contact</h2>
            <p>Questions: <a href="mailto:legal@mhsystemslab.com" className="text-sovereign-gold hover:underline">legal@mhsystemslab.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Disclaimer;