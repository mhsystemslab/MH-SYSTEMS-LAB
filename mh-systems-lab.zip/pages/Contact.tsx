import React, { useState } from 'react';
import { Mail, MessageSquare, Globe, CheckCircle } from 'lucide-react';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => setSubmitted(true), 1000);
  };

  if (submitted) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4">
        <div className="bg-white/5 backdrop-blur-md border border-sovereign-gold p-8 rounded-2xl max-w-md w-full text-center">
          <CheckCircle className="w-16 h-16 text-sovereign-gold mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Message Received</h2>
          <p className="text-gray-300 mb-6">Thank you for reaching out. A member of our team will contact you within 24 hours.</p>
          <button onClick={() => setSubmitted(false)} className="text-sovereign-gold underline">Send another message</button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Get In Touch</h1>
        <p className="text-gray-400">Your transformation journey starts with a conversation.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Contact Info Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl">
            <h3 className="text-xl font-bold text-sovereign-gold mb-6">Connect Directly</h3>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-sovereign-gold/10 p-2 rounded-lg text-sovereign-gold">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-semibold text-white">Email</h4>
                  <a href="mailto:contact@mhsystemslab.com" className="text-sm text-gray-400 hover:text-sovereign-gold">contact@mhsystemslab.com</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                 <div className="bg-sovereign-gold/10 p-2 rounded-lg text-sovereign-gold">
                  <MessageSquare size={20} />
                </div>
                <div>
                  <h4 className="font-semibold text-white">WhatsApp</h4>
                  <a href="https://wa.me/971501472676" className="text-sm text-gray-400 hover:text-sovereign-gold">+971 50 147 2676</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                 <div className="bg-sovereign-gold/10 p-2 rounded-lg text-sovereign-gold">
                  <Globe size={20} />
                </div>
                <div>
                  <h4 className="font-semibold text-white">Global Reach</h4>
                  <p className="text-sm text-gray-400">Serving 5 Continents via Digital Infrastructure</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-sovereign-gold/20 to-transparent border border-sovereign-gold/30 p-6 rounded-2xl backdrop-blur-md">
            <h4 className="text-lg font-bold text-sovereign-gold mb-2">💰 About Pricing</h4>
            <p className="text-sm text-gray-300 leading-relaxed">
              We believe transformation should be accessible to everyone. We offer:
            </p>
            <ul className="text-sm text-gray-300 mt-2 space-y-1 list-disc list-inside">
              <li>Flexible payment plans</li>
              <li>Reduced rates for hardship</li>
              <li>Scholarship opportunities</li>
            </ul>
            <p className="mt-3 text-xs italic text-sovereign-light">Your financial situation will never be a barrier.</p>
          </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-2xl space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Full Name *</label>
                <input type="text" required className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-sovereign-gold focus:outline-none focus:ring-1 focus:ring-sovereign-gold transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Email Address *</label>
                <input type="email" required className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-sovereign-gold focus:outline-none focus:ring-1 focus:ring-sovereign-gold transition-colors" />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">I'm Interested In *</label>
              <select required className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-sovereign-gold focus:outline-none focus:ring-1 focus:ring-sovereign-gold transition-colors">
                <option value="" className="bg-gray-900">Select Programme/Service</option>
                <option value="reset" className="bg-gray-900">Sovereign Reset™ (Health)</option>
                <option value="builder" className="bg-gray-900">Sovereign Builder™ (Business)</option>
                <option value="mind" className="bg-gray-900">Sovereign Mind™ (Mental)</option>
                <option value="course" className="bg-gray-900">Certification Courses</option>
                <option value="scholarship" className="bg-gray-900">Scholarship / Financial Aid</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-300">Your Message *</label>
              <textarea required rows={5} placeholder="Tell us about your transformation goals..." className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-white focus:border-sovereign-gold focus:outline-none focus:ring-1 focus:ring-sovereign-gold transition-colors"></textarea>
            </div>

            <div className="flex items-start gap-2">
              <input type="checkbox" required className="mt-1" />
              <p className="text-xs text-gray-400">I understand that pricing is provided upon request and flexible payment options are available.</p>
            </div>

            <button type="submit" className="w-full py-4 bg-sovereign-gold hover:bg-white text-[#0F2027] font-bold rounded-lg transition-colors shadow-lg shadow-sovereign-gold/20">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;