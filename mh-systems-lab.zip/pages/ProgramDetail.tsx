import React from 'react';
import { useParams, NavLink, Navigate } from 'react-router-dom';
import { 
  Leaf, 
  Rocket, 
  Brain, 
  CheckCircle, 
  Layers, 
  Shield, 
  Video, 
  FileText, 
  MessageCircle, 
  Award,
  ArrowRight 
} from 'lucide-react';

const programData: Record<string, {
  title: string;
  subtitle: string;
  icon: React.ElementType;
  outcome: string;
  modules: { title: string; items: string[] }[];
  gumroadLink: string;
  colorAccent: string;
}> = {
  'sovereign-reset': {
    title: 'Sovereign Reset™',
    subtitle: 'Health & Metabolic Optimization',
    icon: Leaf,
    colorAccent: 'text-green-400',
    outcome: 'Restore metabolic health, energy, and long-term biological performance using structured, sustainable systems.',
    modules: [
      {
        title: 'Module 1: Metabolic Foundation',
        items: [
          'Metabolic type awareness',
          'Blood sugar & insulin control frameworks',
          'Inflammation reduction strategies',
          'Gut health optimization systems'
        ]
      },
      {
        title: 'Module 2: Nutrition Sovereignty',
        items: [
          'Personalized nutrition logic',
          'Meal timing & fasting protocols',
          'Supplement decision frameworks',
          'Craving elimination systems'
        ]
      },
      {
        title: 'Module 3: Movement Mastery',
        items: [
          'Metabolism-driven exercise design',
          'Stress-reduction movement protocols',
          'Sleep & recovery optimization',
          'Daily energy management systems'
        ]
      },
      {
        title: 'Module 4: Long-Term Optimization',
        items: [
          'Metabolic maintenance systems',
          'Healthy aging & longevity logic',
          'Performance enhancement protocols',
          'Sustainable wellness habits'
        ]
      }
    ],
    gumroadLink: 'https://gum.co/sovereign-reset'
  },
  'sovereign-builder': {
    title: 'Sovereign Builder™',
    subtitle: 'Business Launch & Growth System',
    icon: Rocket,
    colorAccent: 'text-sovereign-gold',
    outcome: 'Launch, systemize, and scale a digital business using automation-first, sovereign infrastructure.',
    modules: [
      {
        title: 'Module 1: Business Foundation',
        items: [
          'Idea validation frameworks',
          'Market research systems',
          'Business model architecture',
          'Legal & structural setup logic'
        ]
      },
      {
        title: 'Module 2: Brand Sovereignty',
        items: [
          'Brand identity & positioning',
          'Authority-building systems',
          'Website & digital asset creation',
          'Online presence optimization'
        ]
      },
      {
        title: 'Module 3: Marketing Mastery',
        items: [
          'Customer acquisition systems',
          'Content frameworks',
          'Social media automation logic',
          'Sales funnel optimization'
        ]
      },
      {
        title: 'Module 4: Scaling Systems',
        items: [
          'Process & workflow automation',
          'Revenue multiplication models',
          'Expansion & partnership strategies',
          'Long-term business resilience'
        ]
      }
    ],
    gumroadLink: 'https://gum.co/sovereign-builder'
  },
  'sovereign-mind': {
    title: 'Sovereign Mind™',
    subtitle: 'Mental Mastery & Emotional Intelligence',
    icon: Brain,
    colorAccent: 'text-blue-400',
    outcome: 'Develop clarity, emotional control, and elite decision-making under pressure.',
    modules: [
      {
        title: 'Module 1: Mental Foundation',
        items: [
          'Cognitive restructuring techniques',
          'Belief system optimization',
          'Mental clarity protocols',
          'Focus enhancement systems'
        ]
      },
      {
        title: 'Module 2: Emotional Mastery',
        items: [
          'Emotional regulation frameworks',
          'Stress & nervous system control',
          'Relationship intelligence',
          'Communication mastery'
        ]
      },
      {
        title: 'Module 3: Performance Psychology',
        items: [
          'Peak-state activation',
          'Motivation & discipline systems',
          'Habit formation protocols',
          'Behavioral optimization'
        ]
      },
      {
        title: 'Module 4: Sovereign Mindset',
        items: [
          'Leadership psychology',
          'Decision-making frameworks',
          'Resilience & pressure handling',
          'Legacy & identity systems'
        ]
      }
    ],
    gumroadLink: 'https://gum.co/sovereign-mind'
  }
};

const ProgramDetail: React.FC = () => {
  const { programId } = useParams<{ programId: string }>();
  const program = programId ? programData[programId] : undefined;

  if (!program) {
    return <Navigate to="/programmes" replace />;
  }

  return (
    <div className="pb-20">
      {/* Hero */}
      <section className="relative pt-20 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-sovereign-gold/5 via-transparent to-[#0F2027] pointer-events-none"></div>
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className={`inline-flex items-center justify-center p-4 rounded-full bg-white/5 border border-white/10 mb-8 ${program.colorAccent}`}>
            <program.icon size={48} strokeWidth={1.5} />
          </div>
          <h1 className="text-4xl md:text-7xl font-bold mb-4">{program.title}</h1>
          <p className={`text-xl md:text-2xl font-medium mb-8 ${program.colorAccent}`}>
            {program.subtitle}
          </p>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
            {program.outcome}
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* Curriculum */}
          <section>
            <div className="flex items-center gap-3 mb-8">
              <Layers className="text-sovereign-gold" size={28} />
              <h2 className="text-3xl font-bold">Curriculum Framework</h2>
            </div>
            
            <div className="grid gap-6">
              {program.modules.map((module, idx) => (
                <div key={idx} className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-sovereign-gold/30 transition-all duration-300">
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-3">
                    <span className="bg-sovereign-gold/10 text-sovereign-gold text-sm px-2 py-1 rounded">
                      0{idx + 1}
                    </span>
                    {module.title}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {module.items.map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-gray-300 text-sm">
                        <CheckCircle size={16} className="text-sovereign-gold/60 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Delivery Ecosystem */}
          <section className="bg-[#0F2027]/50 border border-white/10 rounded-2xl p-8 backdrop-blur-md">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Shield className="text-sovereign-gold" /> Professional Delivery
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
               <div className="flex flex-col items-center text-center gap-2">
                 <Video className="text-sovereign-gold/80" />
                 <span className="text-sm font-medium">Video Lessons</span>
               </div>
               <div className="flex flex-col items-center text-center gap-2">
                 <FileText className="text-sovereign-gold/80" />
                 <span className="text-sm font-medium">Workbooks (PDF)</span>
               </div>
               <div className="flex flex-col items-center text-center gap-2">
                 <MessageCircle className="text-sovereign-gold/80" />
                 <span className="text-sm font-medium">Community Access</span>
               </div>
               <div className="flex flex-col items-center text-center gap-2">
                 <Award className="text-sovereign-gold/80" />
                 <span className="text-sm font-medium">Completion Certificate</span>
               </div>
               <div className="flex flex-col items-center text-center gap-2">
                 <Layers className="text-sovereign-gold/80" />
                 <span className="text-sm font-medium">Lifetime Access</span>
               </div>
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <div className="bg-white/5 backdrop-blur-xl border border-sovereign-gold/30 rounded-2xl p-8 text-center shadow-[0_0_40px_rgba(0,0,0,0.4)]">
              <h3 className="text-2xl font-bold text-white mb-2">Begin Your Journey</h3>
              <p className="text-gray-400 text-sm mb-8">
                Join the ecosystem of sovereign individuals.
              </p>
              
              <div className="space-y-4">
                <a 
                  href={program.gumroadLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-4 bg-sovereign-gold hover:bg-white text-[#0F2027] font-bold text-lg rounded-lg transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)]"
                >
                  Request Catalog
                </a>
                <NavLink 
                  to="/contact"
                  className="block w-full py-3 border border-sovereign-gold text-sovereign-gold hover:bg-sovereign-gold/10 font-medium rounded-lg transition-colors"
                >
                  Scholarship Options
                </NavLink>
              </div>
              <p className="mt-6 text-xs text-gray-500">
                Secure transaction via Gumroad. No billing risk.
              </p>
            </div>

             <div className="p-6 rounded-2xl bg-white/5 border border-white/5">
                <h4 className="font-bold text-sovereign-gold mb-2">Education for All</h4>
                <p className="text-sm text-gray-400">
                   Our mission is accessible transformation. If you cannot afford the full program, please contact us. No one is turned away for lack of funds.
                </p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgramDetail;