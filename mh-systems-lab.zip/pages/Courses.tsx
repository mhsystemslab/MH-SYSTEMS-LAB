import React from 'react';
import { NavLink } from 'react-router-dom';
import { BookOpen, Award, Clock, Rocket, Brain, Activity, ArrowRight, Bot, Heart } from 'lucide-react';

const Courses: React.FC = () => {
  const courses = [
    {
      id: 'ai-wellness-coach',
      title: 'AI Wellness Coach Certification',
      duration: '6 Weeks',
      desc: 'Become a certified AI-augmented wellness coach. Scale your practice with personalized AI protocols.',
      icon: Bot
    },
    {
      id: 'business-builder',
      title: 'Business Builder Accelerator',
      duration: '30 Days',
      desc: 'Zero to profitable business. We handle website, marketing, and automation setup for you.',
      icon: Rocket
    },
    {
      id: 'metabolic-health',
      title: 'Metabolic Health Practitioner',
      duration: '8 Weeks',
      desc: 'Comprehensive training in diabetes reversal and metabolic health optimization.',
      icon: Activity
    },
    {
      id: 'emotional-mastery',
      title: 'Emotional Mastery Facilitator',
      duration: '8 Weeks',
      desc: 'Train to guide others through deep emotional healing and resilience building.',
      icon: Heart
    },
    {
      id: 'family-systems',
      title: 'Relationship & Family Systems',
      duration: '4 Weeks',
      desc: 'Strengthen your relationships with proven frameworks. Family harmony through evidence-based methods.',
      icon: UsersIcon
    },
    {
      id: 'addiction-recovery',
      title: 'Addiction Recovery Toolkit',
      duration: '6 Weeks',
      desc: 'Breaking Free Protocol: Science-backed recovery systems and relapse prevention strategies.',
      icon: ShieldIcon
    },
    {
      id: 'teen-transformation',
      title: 'Teen Transformation System',
      duration: 'Self-Paced',
      desc: 'Academic excellence and mental wellness toolkit. Helping teens reach their full potential.',
      icon: StarIcon
    },
    {
      id: 'marriage-mastery',
      title: 'Marriage Communication Mastery',
      duration: '4 Weeks',
      desc: 'Resolve conflicts and build stronger bonds. The conflict-to-connection guide.',
      icon: HeartHandshakeIcon
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 pb-24">
       <div className="text-center mb-16 space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold">Qualification-Only Courses</h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Professional certification programs with instant digital delivery. 
          Master the systems that drive transformation.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {courses.map((course, idx) => (
          <div key={idx} className="glass-panel p-6 rounded-2xl border border-white/10 hover:border-sovereign-gold/50 transition-all duration-300 flex flex-col bg-white/5 backdrop-blur-md group hover:-translate-y-1">
            <div className="flex justify-between items-start mb-4">
              <span className="px-3 py-1 bg-sovereign-gold/10 text-sovereign-gold rounded-full text-[10px] font-bold border border-sovereign-gold/20 uppercase tracking-wide">
                Certification
              </span>
              <div className="flex items-center gap-1 text-gray-400 text-xs">
                <Clock size={12} /> {course.duration}
              </div>
            </div>

            <div className="mb-4 text-sovereign-gold opacity-80">
              {course.icon ? <course.icon size={24} /> : <BookOpen size={24} />}
            </div>

            <h3 className="text-lg font-bold mb-2 text-white group-hover:text-sovereign-gold transition-colors">{course.title}</h3>
            <p className="text-sm text-gray-400 mb-6 flex-grow leading-relaxed">{course.desc}</p>

            <div className="mt-auto grid gap-3">
              <NavLink 
                to={`/courses/${course.id}`}
                className="w-full py-2.5 bg-sovereign-gold hover:bg-white text-[#0F2027] font-bold text-sm rounded-lg text-center transition-colors flex items-center justify-center gap-2"
              >
                View Curriculum <ArrowRight size={14} />
              </NavLink>
              <NavLink 
                to="/contact"
                className="w-full py-2.5 border border-white/20 hover:border-sovereign-gold text-gray-300 hover:text-sovereign-gold font-medium text-sm rounded-lg text-center transition-colors"
              >
                Request Catalog
              </NavLink>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-20 bg-[#0F2027]/50 border border-white/10 rounded-2xl p-8 backdrop-blur-md">
        <h3 className="text-xl font-bold text-sovereign-gold mb-8 text-center">All Certifications Include:</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {[
                {icon: BookOpen, text: "Complete Curriculum"},
                {icon: Award, text: "Professional Certification"},
                {icon: Rocket, text: "Instant Delivery"},
                {icon: Brain, text: "AI Tools & Templates"},
                {icon: Clock, text: "Lifetime Access"},
                {icon: Activity, text: "Community Support"},
            ].map((feat, i) => (
                <div key={i} className="flex flex-col items-center text-center gap-3 group">
                    <div className="p-3 rounded-full bg-white/5 group-hover:bg-sovereign-gold/20 transition-colors">
                      <feat.icon className="text-sovereign-gold w-6 h-6"/>
                    </div>
                    <span className="text-xs font-medium text-gray-300 group-hover:text-white transition-colors">{feat.text}</span>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

// Icons needed for the listing
const UsersIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
);
const ShieldIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);
const StarIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
);
const HeartHandshakeIcon = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/><path d="M12 5 9.04 7.96a2.17 2.17 0 0 0 0 3.08v0c.82.82 2.13.85 3 .07l2.07-1.9a2.82 2.82 0 0 1 3.18 0l2.94 2.69c.78.72 2.07.75 2.89-.07v0a2.17 2.17 0 0 0 0-3.08Z"/></svg>
);

export default Courses;