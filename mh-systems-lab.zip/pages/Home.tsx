import React from 'react';
import { NavLink } from 'react-router-dom';
import { ArrowRight, Star, Shield, Activity, TrendingUp, Leaf, Rocket, Brain } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center px-4 overflow-hidden">
        <div className="absolute inset-0 bg-radial-gradient from-sovereign-gold/10 via-transparent to-transparent opacity-50 pointer-events-none"></div>
        
        <div className="relative z-10 max-w-5xl mx-auto text-center space-y-8">
          <div className="inline-block animate-fade-in-up">
            <span className="px-4 py-1.5 rounded-full border border-sovereign-gold/30 bg-sovereign-gold/10 text-sovereign-gold text-sm font-medium tracking-wide italic">
              The Sovereign Method™
            </span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-tight">
            From Struggle to <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sovereign-gold via-sovereign-light to-sovereign-gold animate-shimmer">
              Sovereign™
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto font-light">
            Systems for Mind, Body & Business Mastery. The strategic ecosystem for total performance.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <NavLink 
              to="/programmes" 
              className="w-full sm:w-auto px-8 py-4 bg-sovereign-gold text-[#0F2027] rounded-lg font-bold text-lg hover:bg-white transition-all duration-300 shadow-[0_0_20px_rgba(212,175,55,0.3)] flex items-center justify-center gap-2"
            >
              Explore Programmes <ArrowRight size={20} />
            </NavLink>
            <NavLink 
              to="/contact" 
              className="w-full sm:w-auto px-8 py-4 border border-sovereign-gold text-sovereign-gold rounded-lg font-bold text-lg hover:bg-sovereign-gold/10 transition-all duration-300 backdrop-blur-sm"
            >
              Free Consultation
            </NavLink>
          </div>
        </div>
      </section>

      {/* Core Programs Preview */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Sovereign Core Programs</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Comprehensive systems designed for total life mastery. Select your path.</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <NavLink to="/programmes/sovereign-reset" className="group bg-white/5 border border-white/10 p-8 rounded-2xl hover:border-green-400/50 transition-all duration-300 hover:-translate-y-2">
            <div className="bg-green-400/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6 text-green-400 group-hover:scale-110 transition-transform">
              <Leaf size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Sovereign Reset™</h3>
            <p className="text-green-400/80 text-sm font-medium mb-4">Health & Metabolic Optimization</p>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Restore metabolic health, energy, and long-term biological performance using structured, sustainable systems.
            </p>
            <div className="flex items-center text-green-400 font-bold text-sm">
              View Curriculum <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </NavLink>

          <NavLink to="/programmes/sovereign-builder" className="group bg-white/5 border border-white/10 p-8 rounded-2xl hover:border-sovereign-gold/50 transition-all duration-300 hover:-translate-y-2 relative overflow-hidden">
             <div className="absolute top-0 right-0 bg-sovereign-gold text-[#0F2027] text-xs font-bold px-3 py-1 rounded-bl-lg">Most Popular</div>
            <div className="bg-sovereign-gold/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6 text-sovereign-gold group-hover:scale-110 transition-transform">
              <Rocket size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Sovereign Builder™</h3>
            <p className="text-sovereign-gold/80 text-sm font-medium mb-4">Business Launch & Growth</p>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Launch, systemize, and scale a digital business using automation-first, sovereign infrastructure.
            </p>
            <div className="flex items-center text-sovereign-gold font-bold text-sm">
              View Curriculum <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </NavLink>

          <NavLink to="/programmes/sovereign-mind" className="group bg-white/5 border border-white/10 p-8 rounded-2xl hover:border-blue-400/50 transition-all duration-300 hover:-translate-y-2">
            <div className="bg-blue-400/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6 text-blue-400 group-hover:scale-110 transition-transform">
              <Brain size={32} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Sovereign Mind™</h3>
            <p className="text-blue-400/80 text-sm font-medium mb-4">Mental Mastery</p>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Develop clarity, emotional control, and elite decision-making under pressure.
            </p>
            <div className="flex items-center text-blue-400 font-bold text-sm">
              View Curriculum <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
            </div>
          </NavLink>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Lives Transformed', value: '750+' },
            { label: 'Businesses Launched', value: '28' },
            { label: 'Continents Served', value: '5' },
            { label: 'Automated Systems', value: '100%' },
          ].map((stat, idx) => (
            <div key={idx} className="bg-white/5 backdrop-blur-md border border-white/10 p-6 rounded-2xl text-center hover:border-sovereign-gold/50 transition-colors group">
              <h3 className="text-3xl md:text-4xl font-bold text-sovereign-gold mb-2 group-hover:scale-110 transition-transform">{stat.value}</h3>
              <p className="text-sm text-gray-400 uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Methodology Section */}
      <section className="max-w-7xl mx-auto px-4 py-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">The Sovereign Method™</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">A proven 4-phase transformation framework spanning mind, body, and business.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { step: '01', title: 'Assessment', desc: 'Deep analysis of current state across all life domains.', icon: Activity },
            { step: '02', title: 'Systemize', desc: 'Deploy proven frameworks and AI automation.', icon: Shield },
            { step: '03', title: 'Optimize', desc: 'Refine systems for maximum efficiency and scale.', icon: TrendingUp },
            { step: '04', title: 'Sovereignty', desc: 'Achieve complete autonomy and build legacy.', icon: Star },
          ].map((phase, idx) => (
            <div key={idx} className="relative p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md hover:-translate-y-2 transition-transform duration-300">
              <div className="absolute top-4 right-4 text-sovereign-gold/20 text-6xl font-bold select-none">{phase.step}</div>
              <phase.icon className="w-10 h-10 text-sovereign-gold mb-6" />
              <h3 className="text-xl font-bold mb-3">{phase.title}</h3>
              <p className="text-gray-400 text-sm leading-relaxed">{phase.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Core CTA */}
      <section className="max-w-4xl mx-auto px-4 text-center py-10">
        <div className="p-10 rounded-3xl bg-gradient-to-b from-sovereign-gold/10 to-transparent border border-sovereign-gold/20 backdrop-blur-lg">
          <h2 className="text-3xl font-bold mb-4">Education for All</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Our mission is accessible transformation. We work with all budgets. 
            Your financial situation will never be a barrier to your sovereignty.
          </p>
          <NavLink 
            to="/contact" 
            className="inline-flex items-center gap-2 px-8 py-4 bg-sovereign-gold text-[#0F2027] font-bold rounded-lg hover:bg-white transition-colors"
          >
            Contact for Catalog <ArrowRight size={18} />
          </NavLink>
        </div>
      </section>
    </div>
  );
};

export default Home;