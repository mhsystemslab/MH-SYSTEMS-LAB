import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Play, Pause, Clock, Calendar, Mic, Headphones, ExternalLink } from 'lucide-react';

const Podcast: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  const episodes = [
    {
      id: 47,
      slug: "breaking-free-limiting-beliefs",
      title: "Breaking Free from Limiting Beliefs",
      date: "Dec 15, 2024",
      duration: "45 min",
      desc: "Discover how to identify and eliminate the beliefs that keep you stuck in struggle mode. We dive deep into cognitive restructuring techniques.",
      image: "bg-blue-500/10"
    },
    {
      id: 46,
      slug: "science-metabolic-optimization",
      title: "The Science of Metabolic Optimization",
      date: "Dec 08, 2024",
      duration: "38 min",
      desc: "Learn evidence-based strategies for optimizing your metabolism, including circadian alignment and nutrient timing.",
      image: "bg-green-500/10"
    },
    {
      id: 45,
      slug: "idea-to-profitable-business",
      title: "From Idea to Profitable Business",
      date: "Dec 01, 2024",
      duration: "52 min",
      desc: "Complete framework for launching your first profitable business. From validation to your first sale in 30 days.",
      image: "bg-sovereign-gold/10"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 pb-24">
      
      {/* Hero Section */}
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">The Sovereign Systems Show</h1>
        <p className="text-xl text-sovereign-gold italic font-light">Weekly insights on mind, body, and business mastery</p>
      </section>

      {/* Main Player (Featured/Latest) */}
      <section className="mb-20">
        <div className="bg-white/5 backdrop-blur-xl border border-sovereign-gold/30 rounded-3xl p-8 md:p-12 relative overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.3)]">
          <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
            <Mic size={200} className="text-white" />
          </div>
          
          <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
            {/* Visualizer */}
            <div className="w-full md:w-1/3 flex flex-col items-center justify-center">
              <div className="w-48 h-48 rounded-full bg-black/40 border-4 border-sovereign-gold/20 flex items-center justify-center relative group cursor-pointer" onClick={() => setIsPlaying(!isPlaying)}>
                {isPlaying ? <Pause size={48} className="text-sovereign-gold" /> : <Play size={48} className="text-sovereign-gold ml-2" />}
                
                {/* Waveform Animation */}
                <div className={`absolute inset-0 flex items-center justify-center gap-1 ${isPlaying ? 'opacity-100' : 'opacity-30'}`}>
                  {[...Array(8)].map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-1.5 bg-sovereign-gold/60 rounded-full transition-all duration-300`}
                      style={{
                        height: isPlaying ? `${Math.random() * 60 + 20}%` : '20%',
                        animation: isPlaying ? `pulse 0.5s infinite alternate ${i * 0.1}s` : 'none'
                      }}
                    />
                  ))}
                </div>
              </div>
              <p className="mt-4 text-xs text-gray-400 uppercase tracking-widest">Latest Episode</p>
            </div>

            {/* Info */}
            <div className="w-full md:w-2/3 space-y-4">
              <div className="flex items-center gap-3 text-sm text-sovereign-gold">
                <span className="px-2 py-1 bg-sovereign-gold/10 rounded border border-sovereign-gold/20">Episode #47</span>
                <span className="flex items-center gap-1"><Calendar size={14} /> Dec 15, 2024</span>
              </div>
              
              <NavLink to="/podcast/breaking-free-limiting-beliefs" className="block group">
                <h2 className="text-3xl font-bold text-white leading-tight group-hover:text-sovereign-gold transition-colors">
                  Breaking Free from Limiting Beliefs
                </h2>
              </NavLink>
              <p className="text-gray-300 text-lg leading-relaxed">
                Discover how to identify and eliminate the beliefs that keep you stuck in struggle mode. 
                We dive deep into cognitive restructuring techniques and the neuroscience of change.
              </p>
              
              {/* Controls */}
              <div className="pt-6 flex flex-col sm:flex-row gap-4 items-center w-full">
                <button 
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-full sm:w-auto px-8 py-3 bg-sovereign-gold text-[#0F2027] font-bold rounded-lg hover:bg-white transition-colors flex items-center justify-center gap-2"
                >
                  {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                  {isPlaying ? 'Pause Episode' : 'Play Latest Episode'}
                </button>
                
                <div className="flex-grow w-full bg-white/10 h-2 rounded-full overflow-hidden">
                  <div className="h-full bg-sovereign-gold w-1/3 rounded-full relative">
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg"></div>
                  </div>
                </div>
                <span className="text-xs text-gray-400 font-mono">14:20 / 45:00</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Library */}
      <section>
        <div className="flex justify-between items-end mb-8 border-b border-white/10 pb-4">
          <h2 className="text-3xl font-bold flex items-center gap-3">
            <Headphones className="text-sovereign-gold" /> All Episodes
          </h2>
          <span className="text-sm text-gray-400 hidden sm:inline-block">Updated Weekly</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {episodes.map((ep) => (
            <div key={ep.id} className="group bg-white/5 border border-white/10 hover:border-sovereign-gold/50 rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1">
              <NavLink to={`/podcast/${ep.slug}`}>
                <div className={`h-32 rounded-xl mb-6 ${ep.image} flex items-center justify-center relative overflow-hidden`}>
                  <div className="absolute inset-0 flex items-center justify-center gap-1 opacity-50">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="w-1 bg-white/40 h-8 rounded-full" style={{ height: `${Math.random() * 60 + 20}%` }}></div>
                    ))}
                  </div>
                  <div className="w-12 h-12 bg-black/40 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:scale-110 transition-transform">
                    <Play size={20} className="text-white ml-1" />
                  </div>
                </div>
              </NavLink>

              <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                <span>Episode #{ep.id}</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {ep.duration}</span>
              </div>

              <NavLink to={`/podcast/${ep.slug}`}>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-sovereign-gold transition-colors line-clamp-2">
                  {ep.title}
                </h3>
              </NavLink>
              
              <p className="text-sm text-gray-400 mb-6 line-clamp-3">
                {ep.desc}
              </p>

              <NavLink 
                to={`/podcast/${ep.slug}`}
                className="block w-full py-2 border border-white/20 rounded-lg text-sm font-medium hover:bg-white/10 hover:border-sovereign-gold/50 transition-colors text-center"
              >
                Listen Now
              </NavLink>
            </div>
          ))}
        </div>
      </section>

      {/* Subscribe */}
      <section className="mt-20">
        <div className="bg-[#0F2027]/50 border border-white/10 rounded-2xl p-8 backdrop-blur-md text-center">
          <h3 className="text-2xl font-bold mb-6">Never Miss an Episode</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {['Apple Podcasts', 'Spotify', 'Google Podcasts', 'RSS Feed'].map((platform) => (
              <a 
                key={platform}
                href="#" 
                className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors"
              >
                {platform} <ExternalLink size={14} className="text-gray-500" />
              </a>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
};

export default Podcast;