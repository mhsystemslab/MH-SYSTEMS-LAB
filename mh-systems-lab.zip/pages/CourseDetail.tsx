import React from 'react';
import { useParams, NavLink, Navigate } from 'react-router-dom';
import { 
  Clock, 
  Award, 
  CheckCircle, 
  BookOpen, 
  Users, 
  ArrowRight, 
  Star,
  Shield
} from 'lucide-react';

const courseData: Record<string, {
  title: string;
  subtitle: string;
  duration: string;
  level: string;
  description: string;
  curriculum: string[];
  outcomes: string[];
  gumroadLink: string;
}> = {
  'ai-wellness-coach': {
    title: 'AI Wellness Coach Certification',
    subtitle: 'Future-proof your coaching practice with AI',
    duration: '6 Weeks',
    level: 'Advanced',
    description: 'Become a certified AI-augmented wellness coach. Learn to leverage artificial intelligence to personalize nutrition plans, track client progress, and scale your impact without burnout. This course bridges the gap between human empathy and algorithmic precision.',
    curriculum: [
      'Module 1: AI Fundamentals for Health Pros',
      'Module 2: Prompt Engineering for Client Plans',
      'Module 3: Automating Client Check-ins',
      'Module 4: Ethics & Human-AI Balance',
      'Module 5: Building Your AI Tech Stack',
      'Module 6: Marketing Your Tech-Enabled Practice'
    ],
    outcomes: [
      'Master AI tools for health assessment',
      '10x your client capacity without burnout',
      'Create hyper-personalized protocols instantly',
      'Launch a modern, scalable coaching business'
    ],
    gumroadLink: 'https://gum.co/ai-wellness'
  },
  'emotional-mastery': {
    title: 'Emotional Mastery Facilitator',
    subtitle: 'Guide others to emotional freedom',
    duration: '8 Weeks',
    level: 'Intermediate',
    description: 'Train to facilitate deep emotional healing and resilience building. Learn frameworks to help clients regulate their nervous systems, process difficult emotions, and master their internal landscape.',
    curriculum: [
      'Module 1: The Physiology of Emotion',
      'Module 2: Somatic Processing Techniques',
      'Module 3: Cognitive Reframing Protocols',
      'Module 4: Facilitating Group Breakthroughs',
      'Module 5: Trauma-Informed Coaching Principles',
      'Module 6: The Facilitator\'s Presence'
    ],
    outcomes: [
      'Certified to lead Emotional Mastery workshops',
      'Deep understanding of nervous system regulation',
      'Toolkit for trauma-informed coaching',
      'Strategies for high-impact client breakthroughs'
    ],
    gumroadLink: 'https://gum.co/emotional-mastery'
  },
  'family-systems': {
    title: 'Relationship & Family Systems',
    subtitle: 'Restore harmony and build generational resilience',
    duration: '4 Weeks',
    level: 'Intermediate',
    description: 'A comprehensive framework for understanding and healing family dynamics. This course provides evidence-based tools to resolve deep-seated conflicts, improve communication, and break cycles of intergenerational trauma.',
    curriculum: [
      'Module 1: The Architecture of Family Dynamics',
      'Module 2: Conflict Resolution Frameworks',
      'Module 3: Healing Intergenerational Patterns',
      'Module 4: Building a Shared Family Vision'
    ],
    outcomes: [
      'Master conflict de-escalation techniques',
      'Understand attachment styles in family contexts',
      'Create safe spaces for difficult conversations',
      'Develop a long-term family unity plan'
    ],
    gumroadLink: 'https://gum.co/familysystems'
  },
  'addiction-recovery': {
    title: 'Addiction Recovery Toolkit',
    subtitle: 'Science-backed protocols for lasting freedom',
    duration: '6 Weeks',
    level: 'All Levels',
    description: 'The Breaking Free Protocol combines neuroscience, behavioral psychology, and spiritual principles to support recovery. Designed for individuals seeking recovery and the families supporting them.',
    curriculum: [
      'Module 1: The Neuroscience of Addiction',
      'Module 2: Identifying Triggers & Environmental Design',
      'Module 3: The Physiology of Detox & Healing',
      'Module 4: Relapse Prevention Strategies',
      'Module 5: Rebuilding Trust & Relationships',
      'Module 6: Finding Purpose Post-Recovery'
    ],
    outcomes: [
      'Understand the biological basis of addiction',
      'Create a robust relapse prevention plan',
      'Rebuild dopamine sensitivity naturally',
      'Navigate social situations with confidence'
    ],
    gumroadLink: 'https://gum.co/recovery'
  },
  'business-builder': {
    title: 'Business Builder Accelerator',
    subtitle: 'Zero to profitable business in 30 days',
    duration: '30 Days',
    level: 'Beginner to Intermediate',
    description: 'A rapid implementation program that handles the heavy lifting of starting a business. We provide the systems, you provide the passion. Focuses on service-based businesses and digital products.',
    curriculum: [
      'Week 1: Niche Selection & Offer Design',
      'Week 2: Branding & Identity Workshop',
      'Week 3: Digital Infrastructure Setup',
      'Week 4: Marketing Automation & Launch'
    ],
    outcomes: [
      'Launch a professional website',
      'Set up automated payment systems',
      'Create a 90-day content marketing plan',
      'Acquire your first paying client'
    ],
    gumroadLink: 'https://gum.co/digitalbiz'
  },
  'teen-transformation': {
    title: 'Teen Transformation System',
    subtitle: 'Empowering the next generation',
    duration: 'Self-Paced',
    level: 'Beginner',
    description: 'Designed specifically for adolescents facing the unique pressures of the modern world. This toolkit addresses academic performance, social anxiety, digital hygiene, and emotional intelligence.',
    curriculum: [
      'Module 1: Self-Identity & Confidence',
      'Module 2: Academic High-Performance Hacks',
      'Module 3: Navigating Social Media & Peer Pressure',
      'Module 4: Emotional Regulation for Teens'
    ],
    outcomes: [
      'Improve grades through study systems',
      'Build resilience against bullying/pressure',
      'Develop healthy digital habits',
      'Plan a compelling future vision'
    ],
    gumroadLink: 'https://gum.co/teensuccess'
  },
  'marriage-mastery': {
    title: 'Marriage Communication Mastery',
    subtitle: 'From conflict to deep connection',
    duration: '4 Weeks',
    level: 'All Levels',
    description: 'Learn the "Conflict-to-Connection" methodology. This course transforms how couples communicate, turning arguments into opportunities for intimacy and understanding.',
    curriculum: [
      'Module 1: The 4 Communication Styles',
      'Module 2: Active Listening & Validation',
      'Module 3: De-escalating Heated Moments',
      'Module 4: Reigniting Intimacy & Trust'
    ],
    outcomes: [
      'Stop cyclical arguments instantly',
      'Feel heard and understood by your partner',
      'Restore emotional and physical intimacy',
      'Align on financial and life goals'
    ],
    gumroadLink: 'https://gum.co/marriage'
  },
  'metabolic-health': {
    title: 'Metabolic Health Practitioner',
    subtitle: 'Expert training in reversal and optimization',
    duration: '8 Weeks',
    level: 'Advanced',
    description: 'A professional certification course for those wishing to guide others in metabolic health. Covers diabetes reversal, insulin sensitivity, fasting protocols, and personalized nutrition.',
    curriculum: [
      'Module 1: The Biochemistry of Metabolism',
      'Module 2: Insulin Resistance & Chronic Disease',
      'Module 3: Nutritional Protocols (Keto, Paleo, Carnivore)',
      'Module 4: Fasting Regimens & Safety',
      'Module 5: Client Assessment & Bloodwork Analysis',
      'Module 6: Building Your Health Practice'
    ],
    outcomes: [
      'Become a certified Metabolic Health Practitioner',
      'Interpret complex metabolic panels',
      'Design personalized health protocols',
      'Launch a health coaching practice'
    ],
    gumroadLink: 'https://gum.co/metabolic'
  }
};

const CourseDetail: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const course = courseId ? courseData[courseId] : undefined;

  if (!course) {
    return <Navigate to="/courses" replace />;
  }

  return (
    <div className="pb-20">
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-radial-gradient from-sovereign-gold/10 via-transparent to-transparent opacity-30 pointer-events-none"></div>
        <div className="max-w-4xl mx-auto text-center space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-sovereign-gold/30 bg-sovereign-gold/10 text-sovereign-gold text-sm font-medium">
            <Award size={14} />
            <span>Professional Certification</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold leading-tight">
            {course.title}
          </h1>
          <p className="text-xl text-sovereign-gold font-light italic">
            {course.subtitle}
          </p>
          
          <div className="flex flex-wrap justify-center gap-6 text-sm text-gray-400 mt-4">
            <div className="flex items-center gap-2">
              <Clock size={16} className="text-sovereign-gold" />
              <span>Duration: {course.duration}</span>
            </div>
            <div className="flex items-center gap-2">
              <BookOpen size={16} className="text-sovereign-gold" />
              <span>Level: {course.level}</span>
            </div>
            <div className="flex items-center gap-2">
              <Users size={16} className="text-sovereign-gold" />
              <span>Community Access</span>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12">
          {/* Overview */}
          <section className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8">
            <h2 className="text-2xl font-bold mb-4 text-white">Course Overview</h2>
            <p className="text-gray-300 leading-relaxed text-lg">
              {course.description}
            </p>
          </section>

          {/* Curriculum */}
          <section>
            <h2 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
              <BookOpen className="text-sovereign-gold" /> Curriculum
            </h2>
            <div className="space-y-4">
              {course.curriculum.map((module, idx) => (
                <div key={idx} className="bg-white/5 border border-white/5 rounded-xl p-5 flex items-start gap-4 hover:border-sovereign-gold/30 transition-colors">
                  <div className="bg-sovereign-gold/10 p-2 rounded-lg text-sovereign-gold mt-1">
                    <span className="font-bold text-sm">{idx + 1}</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg text-white">{module}</h3>
                    <p className="text-sm text-gray-400 mt-1">Comprehensive video lessons and workbook exercises.</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Outcomes */}
          <section>
            <h2 className="text-2xl font-bold mb-6 text-white flex items-center gap-2">
              <Star className="text-sovereign-gold" /> What You'll Achieve
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {course.outcomes.map((outcome, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <CheckCircle className="text-sovereign-gold shrink-0 mt-1" size={20} />
                  <span className="text-gray-300">{outcome}</span>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar / Enrollment */}
        <div className="lg:col-span-1">
          <div className="sticky top-32 bg-white/5 backdrop-blur-xl border border-sovereign-gold/30 rounded-2xl p-6 shadow-[0_0_30px_rgba(0,0,0,0.3)]">
            <h3 className="text-xl font-bold mb-2 text-white">Enroll Today</h3>
            <p className="text-gray-400 text-sm mb-6">
              Start your transformation immediately with instant digital access.
            </p>

            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm text-gray-300 py-2 border-b border-white/10">
                <span className="flex items-center gap-2"><Shield size={14}/> 30-Day Guarantee</span>
                <span className="text-sovereign-gold">Included</span>
              </div>
              <div className="flex items-center justify-between text-sm text-gray-300 py-2 border-b border-white/10">
                <span className="flex items-center gap-2"><Award size={14}/> Certificate</span>
                <span className="text-sovereign-gold">Included</span>
              </div>
              
              <div className="pt-4 space-y-3">
                <a 
                  href={course.gumroadLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full py-4 bg-sovereign-gold hover:bg-white text-[#0F2027] font-bold text-center rounded-lg transition-all shadow-[0_0_20px_rgba(212,175,55,0.3)] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)]"
                >
                  Enroll Now
                </a>
                <NavLink 
                  to="/contact"
                  className="block w-full py-3 border border-sovereign-gold text-sovereign-gold hover:bg-sovereign-gold hover:text-[#0F2027] font-medium text-center rounded-lg transition-colors"
                >
                  Request Catalog / Scholarship
                </NavLink>
              </div>

              <p className="text-center text-xs text-gray-500 mt-4">
                *Flexible payment plans available upon request.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;