import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Search, ArrowRight, User, Calendar, Clock, Tag } from 'lucide-react';

const Blog: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = [
    'All', 'Mental Mastery', 'Health Optimization', 'Business Growth', 'AI & Technology', 'Success Stories'
  ];

  const posts = [
    {
      slug: 'breaking-limiting-beliefs',
      title: "The Neuroscience of Breaking Limiting Beliefs",
      category: "Mental Mastery",
      author: "MH Systems Team",
      date: "Dec 15, 2024",
      readTime: "8 min read",
      excerpt: "Discover the latest research on how beliefs form in the brain and evidence-based techniques for rewiring limiting thought patterns for good.",
      image: "bg-blue-500/5"
    },
    {
      slug: 'metabolic-optimization',
      title: "Metabolic Optimization: Beyond Diet and Exercise",
      category: "Health Optimization",
      author: "Dr. Sarah Chen",
      date: "Dec 14, 2024",
      readTime: "12 min read",
      excerpt: "Explore advanced strategies for metabolic health including circadian rhythm optimization, stress management, and personalized nutrition protocols.",
      image: "bg-green-500/5"
    },
    {
      slug: 'zero-to-business',
      title: "From Zero to Business: The Complete Framework",
      category: "Business Growth",
      author: "Mohamoud Hassan",
      date: "Dec 13, 2024",
      readTime: "15 min read",
      excerpt: "Complete step-by-step framework for launching your first profitable business, from ideation to first customer in 30 days.",
      image: "bg-sovereign-gold/5"
    }
  ];

  const filteredPosts = activeCategory === 'All' 
    ? posts 
    : posts.filter(post => post.category === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 pb-24">
      
      {/* Hero */}
      <section className="text-center mb-16 space-y-4">
        <h1 className="text-4xl md:text-6xl font-bold">Lab Notes</h1>
        <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light">
          Insights, strategies, and breakthroughs in human transformation.
        </p>
      </section>

      {/* Categories */}
      <section className="mb-12 overflow-x-auto">
        <div className="flex justify-center min-w-max gap-2 px-4">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === cat 
                  ? 'bg-sovereign-gold text-[#0F2027]' 
                  : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {filteredPosts.map((post) => (
            <article key={post.slug} className="group bg-white/5 border border-white/10 rounded-2xl overflow-hidden hover:border-sovereign-gold/50 transition-all duration-300">
              <div className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-2 py-1 bg-sovereign-gold/10 text-sovereign-gold text-xs font-bold rounded uppercase tracking-wider">
                    {post.category}
                  </span>
                  <div className="flex items-center gap-4 text-xs text-gray-400">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {post.date}</span>
                    <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-white mb-3 group-hover:text-sovereign-gold transition-colors">
                  <NavLink to={`/blog/${post.slug}`}>{post.title}</NavLink>
                </h2>

                <p className="text-gray-400 leading-relaxed mb-6">
                  {post.excerpt}
                </p>

                <div className="flex items-center justify-between border-t border-white/5 pt-6">
                  <div className="flex items-center gap-2 text-sm text-gray-300">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                      <User size={14} />
                    </div>
                    <span>{post.author}</span>
                  </div>
                  
                  <NavLink 
                    to={`/blog/${post.slug}`}
                    className="flex items-center gap-2 text-sovereign-gold font-bold text-sm hover:translate-x-1 transition-transform"
                  >
                    Read Full Article <ArrowRight size={16} />
                  </NavLink>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-1 space-y-8">
          {/* Newsletter */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md">
            <h3 className="text-xl font-bold mb-2 text-white">Subscribe to Lab Notes</h3>
            <p className="text-sm text-gray-400 mb-4">Get the latest transformation strategies delivered to your inbox weekly.</p>
            <form className="space-y-3" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Your email address" 
                className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-3 text-white text-sm focus:border-sovereign-gold focus:outline-none focus:ring-1 focus:ring-sovereign-gold"
              />
              <button className="w-full py-3 bg-sovereign-gold text-[#0F2027] font-bold rounded-lg text-sm hover:bg-white transition-colors">
                Subscribe
              </button>
            </form>
          </div>

          {/* Popular */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-4 text-white">Popular Articles</h3>
            <div className="space-y-4">
              {posts.map((post, i) => (
                <div key={i} className="group cursor-pointer">
                  <h4 className="text-sm font-medium text-gray-300 group-hover:text-sovereign-gold transition-colors line-clamp-2">
                    {post.title}
                  </h4>
                  <span className="text-xs text-gray-500">{post.readTime}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-4 text-white">Topics</h3>
            <div className="flex flex-wrap gap-2">
              {['AI Systems', 'Diabetes Reversal', 'Business Launch', 'Emotional Mastery', 'Leadership', 'Productivity'].map(tag => (
                <span key={tag} className="px-3 py-1 bg-white/5 hover:bg-white/10 rounded text-xs text-gray-300 cursor-pointer transition-colors border border-white/5">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default Blog;