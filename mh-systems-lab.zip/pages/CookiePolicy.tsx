import React from 'react';

const CookiePolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 pb-24">
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-8 md:p-12 shadow-2xl">
        <h1 className="text-3xl md:text-5xl font-bold mb-4 text-white">Cookie Policy</h1>
        <p className="text-sm text-gray-400 mb-8 uppercase tracking-widest border-b border-white/10 pb-4">Last Updated: December 2024</p>
        
        <div className="space-y-8 text-gray-300 leading-relaxed">
          <section>
            <h2 className="text-2xl font-bold text-white mb-4">What Are Cookies</h2>
            <p>Cookies are small text files stored on your device when you visit websites.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">How We Use Cookies</h2>
            <p className="mb-4">We use cookies to:</p>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li>Remember your preferences</li>
              <li>Analyze site performance</li>
              <li>Provide personalized content</li>
              <li>Maintain session security</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Types of Cookies</h2>
            <ul className="list-disc pl-5 space-y-2 marker:text-sovereign-gold">
              <li><strong>Essential:</strong> Required for basic functionality</li>
              <li><strong>Analytics:</strong> Help us understand site usage</li>
              <li><strong>Functional:</strong> Remember your choices</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Managing Cookies</h2>
            <p>You can control cookies through your browser settings. Note that disabling cookies may affect functionality.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mb-4">Contact</h2>
            <p>Questions: <a href="mailto:privacy@mhsystemslab.com" className="text-sovereign-gold hover:underline">privacy@mhsystemslab.com</a></p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy;