import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Star, Heart, Instagram, Linkedin, Facebook, Youtube, Phone, Mail, Globe, Menu, X, ChevronDown } from 'lucide-react';
import Starfield from './Starfield';
import Cursor from './Cursor';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const location = useLocation();

  // Close mobile menu on route change
  useEffect(() => {
    window.scrollTo(0, 0);
    setIsMobileOpen(false);
  }, [location]);

  return (
    <div className="relative min-h-screen text-white/90 font-sans selection:bg-sovereign-gold/30">
      <Starfield />
      <Cursor />

      {/* 
        EXECUTIVE NAVIGATION STYLES 
        Injected directly to ensure exact adherence to the design system provided.
      */}
      <style>{`
        /* EXECUTIVE NAVIGATION - WORLD CLASS STYLING */
        .executive-nav {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          background: rgba(15, 32, 39, 0.85);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border-bottom: 1px solid rgba(212, 175, 55, 0.2);
          z-index: 1000;
          transition: all 0.3s ease;
        }

        .nav-container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 15px 30px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        /* Logo Section */
        .logo {
          display: flex;
          flex-direction: column;
          text-decoration: none;
        }

        .logo-text {
          font-size: 24px;
          font-weight: 800;
          background: linear-gradient(to right, #D4AF37, #F4E4B7);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
          letter-spacing: -0.5px;
        }

        .logo-tagline {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.7);
          font-style: italic;
          margin-top: -2px;
        }

        /* Executive Menu */
        .executive-menu {
          display: none; /* Hidden on mobile by default */
          list-style: none;
          gap: 40px;
          margin: 0;
          padding: 0;
          align-items: center;
        }

        @media (min-width: 1024px) {
          .executive-menu {
            display: flex;
          }
        }

        .menu-item {
          position: relative;
          height: 100%;
          display: flex;
          align-items: center;
        }

        .menu-item > a {
          color: #fff;
          text-decoration: none;
          font-weight: 600;
          font-size: 15px;
          padding: 25px 0;
          display: flex;
          align-items: center;
          gap: 4px;
          transition: all 0.3s ease;
          position: relative;
        }

        .menu-item > a:hover, .menu-item > a.active {
          color: #D4AF37;
        }

        .menu-item > a::after {
          content: '';
          position: absolute;
          bottom: 15px;
          left: 0;
          width: 0;
          height: 2px;
          background: linear-gradient(90deg, #D4AF37, #F4E4B7);
          transition: width 0.3s ease;
        }

        .menu-item:hover > a::after {
          width: 100%;
        }

        /* CTA Button */
        .menu-item a.cta-primary {
          background: linear-gradient(135deg, #D4AF37, #F4E4B7);
          color: #0F2027 !important;
          padding: 10px 24px;
          border-radius: 8px;
          font-weight: 700;
          transition: all 0.3s ease;
          border: 1px solid rgba(212, 175, 55, 0.3);
          box-shadow: 0 0 15px rgba(212, 175, 55, 0.2);
        }

        .menu-item a.cta-primary::after {
          display: none; /* No underline for button */
        }

        .menu-item a.cta-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px rgba(212, 175, 55, 0.4);
          color: #000 !important;
        }

        /* Mega Menu System */
        .has-mega {
          position: relative;
        }

        .mega-menu {
          position: absolute;
          top: 100%;
          left: 50%;
          transform: translateX(-50%) translateY(10px);
          background: rgba(15, 32, 39, 0.95);
          backdrop-filter: blur(30px);
          -webkit-backdrop-filter: blur(30px);
          border: 1px solid rgba(212, 175, 55, 0.2);
          border-top: 3px solid #D4AF37;
          border-radius: 0 0 16px 16px;
          padding: 30px;
          min-width: 800px;
          box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
          opacity: 0;
          visibility: hidden;
          transition: all 0.3s cubic-bezier(0.165, 0.84, 0.44, 1);
          z-index: 1001;
        }

        .has-mega:hover .mega-menu {
          opacity: 1;
          visibility: visible;
          transform: translateX(-50%) translateY(0);
        }

        .mega-content {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 40px;
        }

        .mega-column h4 {
          color: #D4AF37;
          font-size: 14px;
          font-weight: 700;
          margin-bottom: 20px;
          text-transform: uppercase;
          letter-spacing: 1px;
          border-bottom: 1px solid rgba(255,255,255,0.1);
          padding-bottom: 10px;
        }

        .mega-column ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .mega-column li {
          margin-bottom: 12px;
        }

        .mega-column a {
          color: rgba(255, 255, 255, 0.8);
          text-decoration: none;
          font-size: 15px;
          padding: 0;
          display: block;
          transition: all 0.2s ease;
        }

        .mega-column a:hover {
          color: #D4AF37;
          transform: translateX(5px);
        }

        .mega-column a span {
          display: block;
          font-size: 12px;
          color: rgba(255, 255, 255, 0.5);
          margin-top: 2px;
        }

        .mega-column.highlight {
          background: rgba(212, 175, 55, 0.05);
          margin: -30px -30px -30px 0;
          padding: 30px;
          border-left: 1px solid rgba(212, 175, 55, 0.2);
        }

        .explore-btn {
          background: linear-gradient(135deg, #D4AF37, #F4E4B7);
          color: #0F2027;
          padding: 10px 20px;
          border-radius: 6px;
          text-decoration: none;
          font-weight: 700;
          font-size: 13px;
          display: inline-block;
          margin-top: 20px;
          transition: all 0.3s ease;
        }

        .explore-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(212, 175, 55, 0.3);
        }

        .contact-mega .contact-info p {
          color: rgba(255, 255, 255, 0.8);
          font-size: 14px;
          margin-bottom: 10px;
        }

        .contact-mega .contact-info strong {
          color: #D4AF37;
          display: block;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 4px;
        }

        /* Mobile Toggle */
        .mobile-toggle {
          display: block;
          background: none;
          border: none;
          color: #fff;
          cursor: pointer;
        }
        @media (min-width: 1024px) {
          .mobile-toggle {
            display: none;
          }
        }

        /* Mobile Overlay */
        .mobile-menu-overlay {
          position: fixed;
          top: 0;
          right: 0;
          width: 100%;
          height: 100vh;
          background: rgba(15, 32, 39, 0.6);
          backdrop-filter: blur(5px);
          z-index: 1050;
          visibility: hidden;
          opacity: 0;
          transition: all 0.3s ease;
        }

        .mobile-menu-overlay.open {
          visibility: visible;
          opacity: 1;
        }

        .mobile-menu-content {
          position: absolute;
          top: 0;
          right: 0;
          width: 85%;
          max-width: 400px;
          height: 100%;
          background: #0F2027;
          border-left: 1px solid rgba(212, 175, 55, 0.3);
          transform: translateX(100%);
          transition: transform 0.3s cubic-bezier(0.77, 0, 0.175, 1);
          overflow-y: auto;
          box-shadow: -10px 0 30px rgba(0,0,0,0.5);
        }

        .mobile-menu-overlay.open .mobile-menu-content {
          transform: translateX(0);
        }

        .mobile-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 20px;
          border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .mobile-logo {
          font-weight: 800;
          color: #D4AF37;
          font-size: 18px;
        }

        .mobile-menu-list {
          list-style: none;
          padding: 20px;
          margin: 0;
        }

        .mobile-menu-list li {
          margin-bottom: 0;
          border-bottom: 1px solid rgba(255,255,255,0.05);
        }

        .mobile-menu-list a {
          display: block;
          padding: 15px 0;
          color: #fff;
          text-decoration: none;
          font-size: 16px;
        }
        
        .mobile-submenu {
          padding-left: 15px;
          background: rgba(255,255,255,0.03);
          display: none;
        }
        
        .mobile-has-children.open .mobile-submenu {
          display: block;
        }

        .mobile-submenu a {
          font-size: 14px;
          color: #ccc;
          padding: 12px 0;
        }

        .mobile-cta {
          background: #D4AF37 !important;
          color: #0F2027 !important;
          text-align: center;
          border-radius: 8px;
          font-weight: bold;
          margin-top: 20px;
        }
      `}</style>

      {/* EXECUTIVE NAVIGATION */}
      <nav className="executive-nav">
        <div className="nav-container">
          
          {/* Logo Section */}
          <div className="logo-section">
            <NavLink to="/" className="logo">
              <span className="logo-text">MH SYSTEMS LAB</span>
              <span className="logo-tagline">The Sovereign Method™</span>
            </NavLink>
          </div>
          
          {/* Desktop Navigation */}
          <ul className="executive-menu">
            
            {/* Home */}
            <li className="menu-item">
              <NavLink to="/" className={({isActive}) => isActive ? "active" : ""}>Home</NavLink>
            </li>
            
            {/* Programs Mega Menu */}
            <li className="menu-item has-mega">
              <NavLink to="/programmes">Programs <ChevronDown size={14} /></NavLink>
              <div className="mega-menu">
                <div className="mega-content">
                  <div className="mega-column">
                    <h4>Core Programs</h4>
                    <ul>
                      <li><NavLink to="/programmes/sovereign-reset">Sovereign Reset™ <span>Health & Metabolic</span></NavLink></li>
                      <li><NavLink to="/programmes/sovereign-builder">Sovereign Builder™ <span>Business Launch</span></NavLink></li>
                      <li><NavLink to="/programmes/sovereign-mind">Sovereign Mind™ <span>Mental Mastery</span></NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Specialized Programs</h4>
                    <ul>
                      <li><NavLink to="/courses/addiction-recovery">Addiction Recovery</NavLink></li>
                      <li><NavLink to="/courses/teen-transformation">Teen Transformation</NavLink></li>
                      <li><NavLink to="/courses/family-systems">Relationship Systems</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column highlight">
                    <h4>New Programs</h4>
                    <p className="text-sm text-gray-400 mb-4">Transform every dimension of your life with our comprehensive systems.</p>
                    <NavLink to="/programmes" className="explore-btn">Explore All Programs</NavLink>
                  </div>
                </div>
              </div>
            </li>
            
            {/* Services Mega Menu */}
            <li className="menu-item has-mega">
              <a href="#">Services <ChevronDown size={14} /></a>
              <div className="mega-menu">
                <div className="mega-content">
                  <div className="mega-column">
                    <h4>Professional Services</h4>
                    <ul>
                      <li><NavLink to="/contact">Life Coaching & Personal Development</NavLink></li>
                      <li><NavLink to="/programmes/sovereign-reset">Holistic Wellness & Nutrition</NavLink></li>
                      <li><NavLink to="/programmes/sovereign-builder">Business Development & Entrepreneurship</NavLink></li>
                      <li><NavLink to="/courses/marriage-mastery">Relationship & Communication Coaching</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Specialized Services</h4>
                    <ul>
                      <li><NavLink to="/courses/marriage-mastery">Conflict Resolution Strategies</NavLink></li>
                      <li><NavLink to="/courses/addiction-recovery">Addiction Recovery Support</NavLink></li>
                      <li><NavLink to="/courses/teen-transformation">Teen Coaching & Mentoring</NavLink></li>
                      <li><NavLink to="/courses/family-systems">Family Systems Engineering</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column highlight">
                    <h4>Expert Network</h4>
                    <p className="text-sm text-gray-400 mb-4">Access our world-class specialists for personalized guidance.</p>
                    <NavLink to="/experts" className="explore-btn">Meet Our Experts</NavLink>
                  </div>
                </div>
              </div>
            </li>
            
            {/* Learning Hub */}
            <li className="menu-item has-mega">
              <a href="#">Learning <ChevronDown size={14} /></a>
              <div className="mega-menu">
                <div className="mega-content">
                  <div className="mega-column">
                    <h4>Certification Courses</h4>
                    <ul>
                      <li><NavLink to="/courses">AI Wellness Coach Certification</NavLink></li>
                      <li><NavLink to="/courses/business-builder">Business Builder Accelerator</NavLink></li>
                      <li><NavLink to="/courses/metabolic-health">Metabolic Health Practitioner</NavLink></li>
                      <li><NavLink to="/courses">Emotional Mastery Facilitator</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Digital Products</h4>
                    <ul>
                      <li><NavLink to="/resources">Transformation Guides</NavLink></li>
                      <li><NavLink to="/ai-tools">AI Tools & Systems</NavLink></li>
                      <li><NavLink to="/resources">Business Templates</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Content Library</h4>
                    <ul>
                      <li><NavLink to="/blog">Lab Notes (Blog)</NavLink></li>
                      <li><NavLink to="/podcast">The Sovereign Systems Show</NavLink></li>
                      <li><NavLink to="/resources">Success Stories</NavLink></li>
                    </ul>
                  </div>
                </div>
              </div>
            </li>
            
            {/* About Dropdown */}
            <li className="menu-item has-mega">
              <NavLink to="/about">About <ChevronDown size={14} /></NavLink>
              <div className="mega-menu">
                <div className="mega-content">
                  <div className="mega-column">
                    <h4>Our Story</h4>
                    <ul>
                      <li><NavLink to="/about">The Sovereign Method™ Story</NavLink></li>
                      <li><NavLink to="/about">Mission & Values</NavLink></li>
                      <li><NavLink to="/about">Global Impact</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Expert Network</h4>
                    <ul>
                      <li><NavLink to="/experts">Our Team</NavLink></li>
                      <li><NavLink to="/contact">Strategic Partners</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Recognition</h4>
                    <ul>
                      <li><NavLink to="/resources">Success Stories</NavLink></li>
                      <li><NavLink to="/contact">Media & Press</NavLink></li>
                    </ul>
                  </div>
                </div>
              </div>
            </li>
            
            {/* Contact with Mega Options */}
            <li className="menu-item has-mega">
              <NavLink to="/contact" className="cta-primary">Contact <ChevronDown size={14} /></NavLink>
              <div className="mega-menu contact-mega">
                <div className="mega-content">
                  <div className="mega-column">
                    <h4>Get Started</h4>
                    <ul>
                      <li><NavLink to="/contact">Contact Form</NavLink></li>
                      <li><NavLink to="/contact">Free Consultation</NavLink></li>
                      <li><NavLink to="/contact">Request Catalog</NavLink></li>
                      <li><a href="https://wa.me/971501472676" target="_blank" rel="noreferrer">WhatsApp Support</a></li>
                    </ul>
                  </div>
                  <div className="mega-column">
                    <h4>Support</h4>
                    <ul>
                      <li><NavLink to="/contact">Help Center</NavLink></li>
                      <li><NavLink to="/contact">FAQ</NavLink></li>
                      <li><NavLink to="/contact">Community Forum</NavLink></li>
                    </ul>
                  </div>
                  <div className="mega-column contact-info">
                    <h4>Connect Directly</h4>
                    <strong>Email</strong>
                    <p>contact@mhsystemslab.com</p>
                    <strong>WhatsApp</strong>
                    <p>+971 50 147 2676</p>
                    <strong>Response Time</strong>
                    <p>Within 24 hours</p>
                  </div>
                </div>
              </div>
            </li>
          </ul>
          
          {/* Mobile Menu Toggle */}
          <button 
            className="mobile-toggle" 
            aria-label="Toggle menu"
            onClick={() => setIsMobileOpen(true)}
          >
            <Menu size={28} />
          </button>
        </div>
      </nav>

      {/* MOBILE MENU OVERLAY */}
      <div className={`mobile-menu-overlay ${isMobileOpen ? 'open' : ''}`}>
        <div className="mobile-menu-content">
          <div className="mobile-header">
            <span className="mobile-logo">MH Systems Lab</span>
            <button className="mobile-close text-white" onClick={() => setIsMobileOpen(false)}>
              <X size={24} />
            </button>
          </div>
          <ul className="mobile-menu-list">
            <li><NavLink to="/" onClick={() => setIsMobileOpen(false)}>Home</NavLink></li>
            
            <MobileSubMenu title="Programs">
              <li><NavLink to="/programmes/sovereign-reset" onClick={() => setIsMobileOpen(false)}>Sovereign Reset™</NavLink></li>
              <li><NavLink to="/programmes/sovereign-builder" onClick={() => setIsMobileOpen(false)}>Sovereign Builder™</NavLink></li>
              <li><NavLink to="/programmes/sovereign-mind" onClick={() => setIsMobileOpen(false)}>Sovereign Mind™</NavLink></li>
              <li><NavLink to="/programmes" onClick={() => setIsMobileOpen(false)}>All Programs</NavLink></li>
            </MobileSubMenu>

            <MobileSubMenu title="Services">
              <li><NavLink to="/contact" onClick={() => setIsMobileOpen(false)}>Life Coaching</NavLink></li>
              <li><NavLink to="/programmes/sovereign-reset" onClick={() => setIsMobileOpen(false)}>Nutrition Coaching</NavLink></li>
              <li><NavLink to="/programmes/sovereign-builder" onClick={() => setIsMobileOpen(false)}>Business Development</NavLink></li>
              <li><NavLink to="/courses/marriage-mastery" onClick={() => setIsMobileOpen(false)}>Relationship Coaching</NavLink></li>
            </MobileSubMenu>

            <MobileSubMenu title="Learning">
              <li><NavLink to="/courses" onClick={() => setIsMobileOpen(false)}>Courses</NavLink></li>
              <li><NavLink to="/resources" onClick={() => setIsMobileOpen(false)}>Resources</NavLink></li>
              <li><NavLink to="/blog" onClick={() => setIsMobileOpen(false)}>Blog</NavLink></li>
              <li><NavLink to="/podcast" onClick={() => setIsMobileOpen(false)}>Podcast</NavLink></li>
            </MobileSubMenu>

            <li><NavLink to="/about" onClick={() => setIsMobileOpen(false)}>About</NavLink></li>
            <li><NavLink to="/contact" className="mobile-cta" onClick={() => setIsMobileOpen(false)}>Get Catalog</NavLink></li>
          </ul>
        </div>
      </div>

      {/* Main Content */}
      <main className="pt-24">
        {children}
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="col-span-1 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <Star className="w-6 h-6 text-sovereign-gold" />
                <span className="text-lg font-bold text-sovereign-gold">MH SYSTEMS LAB</span>
              </div>
              <p className="text-sm text-gray-400 mb-6 italic">"From Struggle to Sovereign™"</p>
              <div className="flex space-x-4">
                <a href="https://tiktok.com/@mhsystemslab" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sovereign-gold transition-colors"><div className="w-5 h-5 border border-current rounded flex items-center justify-center text-[10px] font-bold">Tk</div></a>
                <a href="https://linkedin.com/company/mhsystemslab" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sovereign-gold transition-colors"><Linkedin size={20} /></a>
                <a href="https://twitter.com/mhsystemslab" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sovereign-gold transition-colors"><div className="w-5 h-5 border border-current rounded flex items-center justify-center text-[10px] font-bold">X</div></a>
                <a href="https://instagram.com/mhsystemslab" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sovereign-gold transition-colors"><Instagram size={20} /></a>
                <a href="https://facebook.com/mhsystemslab" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-sovereign-gold transition-colors"><Facebook size={20} /></a>
              </div>
            </div>

            <div>
              <h4 className="text-sovereign-gold font-semibold mb-4">Programs</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><NavLink to="/programmes" className="hover:text-white transition-colors">Sovereign Reset™</NavLink></li>
                <li><NavLink to="/programmes" className="hover:text-white transition-colors">Sovereign Builder™</NavLink></li>
                <li><NavLink to="/programmes" className="hover:text-white transition-colors">Sovereign Mind™</NavLink></li>
              </ul>
            </div>

            <div>
              <h4 className="text-sovereign-gold font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                 <li className="flex items-center gap-2"><Mail size={14}/> contact@mhsystemslab.com</li>
                 <li className="flex items-center gap-2"><Phone size={14}/> +971 50 147 2676</li>
                 <li className="flex items-center gap-2 mt-2"><Globe size={14}/> Global Infrastructure</li>
                 <li className="text-xs text-gray-500">Serving: Dubai • UK • USA • Kenya • Somalia</li>
              </ul>
            </div>

            <div>
               <h4 className="text-sovereign-gold font-semibold mb-4">Legal</h4>
               <ul className="space-y-2 text-sm text-gray-400">
                <li><NavLink to="/privacy-policy" className="hover:text-white">Privacy Policy</NavLink></li>
                <li><NavLink to="/terms-of-service" className="hover:text-white">Terms of Service</NavLink></li>
                <li><NavLink to="/refund-policy" className="hover:text-white">Refund Policy</NavLink></li>
               </ul>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-white/5 text-center">
            <div className="flex flex-col items-center justify-center gap-2 mb-4">
              <Heart size={16} className="text-sovereign-gold fill-sovereign-gold animate-pulse" />
              <p className="text-sm text-sovereign-light/60 max-w-lg mx-auto italic">
                Built with love as a living memorial. Every transformation honors a legacy of service to humanity.
              </p>
            </div>
            <p className="text-xs text-gray-500">&copy; 2025 MH Systems Lab. All rights reserved.</p>
          </div>
        </div>
      </footer>
      
      {/* Floating WhatsApp */}
      <a 
        href="https://wa.me/971501472676" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] text-white p-4 rounded-full shadow-[0_0_20px_rgba(37,211,102,0.4)] hover:scale-110 transition-transform flex items-center justify-center"
      >
        <Phone className="w-6 h-6" />
      </a>
    </div>
  );
};

// Helper component for Mobile Submenus
const MobileSubMenu: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <li className={`mobile-has-children ${isOpen ? 'open' : ''}`}>
      <button 
        className="w-full text-left flex justify-between items-center py-4 text-white font-semibold"
        onClick={() => setIsOpen(!isOpen)}
      >
        {title} <ChevronDown size={14} className={`transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <ul className="mobile-submenu">
        {children}
      </ul>
    </li>
  );
};

export default Layout;