import React, { useEffect, useState } from 'react';

const Cursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [trailingPosition, setTrailingPosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const updatePosition = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseLeave = () => setIsVisible(false);
    const handleMouseEnter = () => setIsVisible(true);

    window.addEventListener('mousemove', updatePosition);
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('mousemove', updatePosition);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, [isVisible]);

  useEffect(() => {
    const interval = setInterval(() => {
      setTrailingPosition((prev) => ({
        x: prev.x + (position.x - prev.x) * 0.15,
        y: prev.y + (position.y - prev.y) * 0.15,
      }));
    }, 16);

    return () => clearInterval(interval);
  }, [position]);

  if (!isVisible) return null;

  return (
    <>
      {/* Main Cursor */}
      <div 
        className="fixed w-4 h-4 rounded-full pointer-events-none z-[9999] mix-blend-screen bg-sovereign-gold shadow-[0_0_10px_rgba(212,175,55,0.8)]"
        style={{ left: `${position.x}px`, top: `${position.y}px`, transform: 'translate(-50%, -50%)' }}
      />
      {/* Trailing Cursor */}
      <div 
        className="fixed w-8 h-8 rounded-full pointer-events-none z-[9998] bg-sovereign-gold/20 blur-sm transition-transform duration-75"
        style={{ left: `${trailingPosition.x}px`, top: `${trailingPosition.y}px`, transform: 'translate(-50%, -50%)' }}
      />
    </>
  );
};

export default Cursor;